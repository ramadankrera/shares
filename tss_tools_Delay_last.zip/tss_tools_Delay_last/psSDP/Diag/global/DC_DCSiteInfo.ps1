PARAM ( [string] $SiteToCheck = $null ) 
#************************************************ 
# DCSiteInfo.ps1 
# Version 1.0 
# Date: 1/14/2014 
# Author: Tim Springston [MS] 
# Description:  This script queries for the computers domain
#  and returns details about all domain controllers which are in
#  the same site.
#************************************************ 

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
	
Import-LocalizedData -BindingVariable ADInfoStrings
Write-DiagProgress -Activity $AdInfoStrings.ID_ADInfo_Status -Status   $AdInfoStrings.ID_ADInfo_Wait
#| WriteTo-StdOut -shortformat
$global:FormatEnumerationLimit = -1

#Define output file.
if ($SiteToCheck.Length -eq 0)
	{$FileDescription = "Text File containing a list of domain controllers in the Active Directory site of the computer."}
	else
		{$FileDescription = "Text File containing a list of domain controllers in the Active Directory site of $SiteToCheck."}

$SectionDescription = "Active Directory Site Domain Controller List (TXT)"
$ExportFile = Join-Path $Pwd.Path ($ComputerName + "_SiteDCList.txt")

$SiteName = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::GetComputerSite()

"Listing domain controllers in site." | Out-File $ExportFile -Append
"AD Site for the computer is $SiteName" | Out-File $ExportFile -Append
"*********************************************************"| Out-File $ExportFile -Append

$DCCounter = 0

if ($SiteToCheck.Length -eq 0)
	{
	$SiteName = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::GetComputerSite()
	$SiteName = $SiteName.ToString()
	"Checking the computer's current Active Directory site of $SiteName" | Out-File $ExportFile -Append
	$ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
	$Domains = $ForestInfo.get_Domains()
	$SiteDCs = New-Object PSObject
	ForEach ($Domain in $Domains)
		{
		$DCsInSite = $Domain.FindAllDomainControllers($SiteName)
		ForEach ($DCInSite in $DCsInSite)
			{
			$DCObject = New-object PSObject
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'DC Name' -Value $DCInSite.Name
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'SiteName' -Value $DCInSite.SiteName
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Domain' -Value $DCInSite.Domain
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Forest' -Value $DCInSite.Forest
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'IP Address' -Value $DCInSite.IPAddress
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Roles' -Value $DCInSite.Roles
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'HighestCommittedUSN' -Value $DCInSite.HighestCommittedUSN
			Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'OSVersion' -Value $DCInSite.OSVersion
			
			"DC details found for $DCInSite.Name" | Out-File $ExportFile -Append
			$DCObject | Out-File $ExportFile -Append
			$DCObject = $null
			$DCCounter++
			}
		}
	}
	else
		{
		"Checking the user specified Active Directory site of $SiteToCheck" | Out-File $ExportFile -Append
		$ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
		$Domains = $ForestInfo.get_Domains()
		$SiteDCs = New-Object PSObject

		ForEach ($Domain in $Domains)
			{

			$DCsInSite = $Domain.FindAllDomainControllers($SiteToCheck)
			ForEach ($DCInSite in $DCsInSite)
				{
				$DCObject = New-object PSObject
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'DC Name' -Value $DCInSite.Name
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'SiteName' -Value $DCInSite.SiteName
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Domain' -Value $DCInSite.Domain
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Forest' -Value $DCInSite.Forest
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'IP Address' -Value $DCInSite.IPAddress
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'Roles' -Value $DCInSite.Roles
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'HighestCommittedUSN' -Value $DCInSite.HighestCommittedUSN
				Add-Member -InputObject $DCObject -MemberType NoteProperty -Name 'OSVersion' -Value $DCInSite.OSVersion
			
				"DC details found for $DCInSite.Name" | Out-File $ExportFile -Append
				$DCObject | Out-File $ExportFile -Append
				$DCObject = $null
				$DCCounter++
				}
			}
		}


if ($DCCounter -eq 0)
	{
	"The local site $SiteName does not have local domain controllers." | Out-File $ExportFile -Append
	}

CollectFiles -filesToCollect $ExportFile -fileDescription $FileDescription -sectionDescription $SectionDescription -renameOutput $false
