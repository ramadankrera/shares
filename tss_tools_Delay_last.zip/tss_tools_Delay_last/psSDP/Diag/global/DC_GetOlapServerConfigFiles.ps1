New-Variable OLAP_SERVICE_KEY_MASK  -Value "HKLM:\System\CurrentControlSet\Services\*OLAP*"   -Option ReadOnly
New-Variable OLAP_CONFIG_FILE       -Value "MSMDSRV.INI"                                      -Option ReadOnly

function Get-SsasConfigFilePath([object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[Get-SsasConfigFilePath] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
    
    [string]$ConfigFilePath=$null
    
    if ($null -ne $OlapServiceKey)
    {
        $ImagePath =  (Get-ItemProperty -Path $OlapServiceKey.PSPath).ImagePath
        
        if ($null -ne $ImagePath)
        {    
            # The configu file path follows the -s command line parameter imbedded in the image path
            # Example Image Path:
            # "C:\Program Files\Microsoft SQL Server\MSAS10_50.SQL2008R2\OLAP\bin\msmdsrv.exe" -s "C:\Program Files\Microsoft SQL Server\MSAS10_50.SQL2008R2\OLAP\Config"
            $ConfigFilePath = ($ImagePath.Substring($ImagePath.IndexOf("-s")+3)).Trim("`"")
        }
        else
        {
            '[Get-SsasConfigFilePath] : [ERROR] Get-ItemProperty returned a null image path for the OLAP service' | WriteTo-StdOut
        }
        
    }
    else
    {
        '[Get-SsasConfigFilePath] : [ERROR] Required parameter -OlapServiceKey was not specified' | WriteTo-StdOut
    }
    
    return $ConfigFilePath
}

function Get-SsasInstanceName([string]$ServiceName)
{
	$Error.Clear()           
	trap 
	{
		'[Get-SsasInstanceName] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}
	
    if (($null -ne $ServiceName) -and (0 -lt $ServiceName.Length))
    {   
        
        # If named instance split the service name at the $ to get the instance name ...
        if ($ServiceName.Contains("$"))
        {
            $InstanceName = ($ServiceName.Split("$"))[1]
        }
        else
        {
            $InstanceName = $ServiceName
        }   
   }
   else
   {
        '[Get-SsasInstanceName] : [ERROR] Required parameter -ServiceName was not specified.' | WriteTo-StdOut
   }
   
   return $InstanceName
}

function CopyAndCollectSsasConfiguration([object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[CopyAndCollectSsasConfiguration] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error 
	}
	
    if ($null -ne $OlapServiceKey) 
    {
        # Get the instance name from the service name
        $InstanceName = Get-SsasInstanceName $OlapService.PSChildName
    	
    	if (($null -ne $InstanceName) -and (0 -lt $InstanceName.Length))
        {
            # Update msdt dialog that's displayed to user
        	Write-DiagProgress -Activity $ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFile -Status ($ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFileDesc + ": " + $InstanceName)
                
            # Extract the path to the config file from the imagepath
            $ConfigFilePath = Get-SsasConfigFilePath $OlapServiceKey
            
            if ($null -ne $ConfigFilePath)
            {
                # Test Config file path retrieved from the ImagePath in the registry
                if (Test-Path $ConfigFilePath -PathType "Container")
                {    
                    $FileFilters = @($OLAP_CONFIG_FILE)
                    
                    $OlapConfigFile = @()
				    $OlapConfigFile = Copy-FileSql -SourcePath $ConfigFilePath `
                         -FileFilters $FileFilters `
                         -FilePolicy $global:SQL:FILE_POLICY_CONFIGURATION_FILE `
                         -InstanceName $InstanceName `
                         -RenameCollectedFiles `
                         -LCID '1033' `
                         -SectionDescription ("OLAP Configuration File for instance: {0} on server: {1}" -f $InstanceName, $env:ComputerName)
                   
				    "[CopyAndCollectConfiguration] : [INFO] Collected OLAP configuration file: [{0}] file for instance: [{1}]" -f $OlapConfigFile, $InstanceName | WriteTo-StdOut      

                } 
                else
                {
                    "[CopyAndCollectConfiguration] : Invalid path to configuration file: [{0}]" -f $ConfigFilePath | WriteTo-StdOut
                    if ($true -eq (Check-IsSsasDiskResourceOnline $ConfigFilePath))
                    {
                        "[CopyAndCollectSsasConfiguration] : [ERROR] Path to SSAS Configuration file: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
                }
				
			} #if ($null -ne $ConfigFilePath)
			else
			{
				'[CopyAndCollectSsasConfiguration] : [ERROR] Path to the OLAP config path collected was invalid' | WriteTo-StdOut
			}
			
        } # if ($null -ne $InstanceName)
        else
        {
            '[CopyAndCollectSsasConfiguration] : [ERROR] Get-SsasInstanceName returned a null value' | WriteTo-StdOut
        }
    } # if ($null -ne $OlapService)
    else
    {
        '[CopyAndCollectSsasConfiguration] : [ERROR} Required parameter -OlapService was not specified' |WriteTo-Stdout
    }
	
} # function CopyAndCollectSsasConfiguration()


$Error.Clear()           
trap 
{
	"[Get-OlapServerConfigurationFiles] : Trapped error ..." | WriteTo-StdOut
	Show-ErrorDetails $error[0] 
}

Import-LocalizedData -BindingVariable ssasConfigurationCollectorStrings

# Get a list of the installed SSAS services from the HKLM:\SYSTEM\CurrentControlSet key
$OlapServices = @(get-childitem $OLAP_SERVICE_KEY_MASK)

if (0 -lt $OlapServices.Count)
{
	"[DC-GetOlapServerConfigFiles] : Discovered {0} SSAS Service(s)" -f $OlapServices.Count | WriteTo-StdOut
	
    foreach ($OlapService in $OlapServices)
    {      
        "[DC-GetOlapServerConfigFiles] : Collecting server configuration for service: {0}" -f $OlapService.PsChildName | WriteTo-StdOut
        
        CopyAndCollectSsasConfiguration -OlapServiceKey $OlapService
    }
}
else
{
    "[DC_GetOlapConfig] : No OLAP services were found on server: [{0}]" -f $env:COMPUTERNAME | WriteTo-StdOut
}
 