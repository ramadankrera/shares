#************************************************
# DC_HyperVNetworkVirtualization.ps1
# Version 1.0
# Date: May 2014
# Author:  Boyd Benson (bbenson@microsoft.com) with assistance from Tim Quinn (tiquinn@microsoft.com)
# Description: PS cmdlets
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}	
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}



$sectionDescription = "Hyper-V Networking Virtualization"

# detect OS version and SKU
$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile = $Computername + "_HyperVNetworking_HNV.TXT"


"===================================================="	| Out-File -FilePath $OutputFile -append
"Hyper-V Networking Virtualization Settings"			| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization Configuration"			| Out-File -FilePath $OutputFile -append
"  1. Overview stats"									| Out-File -FilePath $OutputFile -append
"       Number of VMs"									| Out-File -FilePath $OutputFile -append
"       Number of VM Network Adapters"					| Out-File -FilePath $OutputFile -append
"       Number of Virtual Switches"						| Out-File -FilePath $OutputFile -append
"       Number of NVLookupRecords"						| Out-File -FilePath $OutputFile -append
"  2. HNV Hierarchical View"							| Out-File -FilePath $OutputFile -append
"       RoutingDomainID / VirtualSubnetID / VMs"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append



$vmmsCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
if ($vmmsCheck)
{
	if ((Get-Service "vmms").Status -eq 'Running')
	{
		if ($bn -gt 9000) 
		{
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Stats:"	| Out-File -FilePath $OutputFile -append
			"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			
			# How many Virtual Machines?
			$vms = Get-VM
			$vmsCount = $vms.length
			"Number of VMs               : " + $vmsCount	| Out-File -FilePath $OutputFile -append

			# How many Virtual Network Adapters?
			$vmNetworkAdapters = get-vmnetworkadapter *
			$vmNetworkAdaptersCount = $vmNetworkAdapters.length
			"Number of VMNetworkAdapters : " + $vmNetworkAdaptersCount	| Out-File -FilePath $OutputFile -append

			# How many Virtual Switches?
			$vmSwitch = get-vmswitch *
			$vmSwitchCount = $vmSwitch.length
			"Number of VMSwitches        : " + $vmSwitchCount	| Out-File -FilePath $OutputFile -append

			# How many Routing Domains (CustomerIDs)?
			# 	Get-NetVirtualizationLookupRecord shows the CustomerID
			#   Get-NetVirtualizationCustomerRoute shows the RoutingDomainID

			$nvLookupRecord = Get-NetVirtualizationLookupRecord
			$nvLookupRecordCount = $nvLookupRecord.length
			"Number of NVLookupRecords   : " + $nvLookupRecordCount		| Out-File -FilePath $OutputFile -append	
			"`n" | Out-File -FilePath $OutputFile -append
			"`n" | Out-File -FilePath $OutputFile -append
			"`n" | Out-File -FilePath $OutputFile -append

			[array]$nvLrCustomerIdsAll = @()
			[array]$nvLrVirtualSubnetIdsAll = @()
			[array]$nvLrProviderAddressesAll = @()
			[array]$nvLrCustomerAddressesAll = @()
			foreach ($lookupRecord in $nvLookupRecord)
			{
				$nvLrCustomerIdsAll       = $nvLrCustomerIdsAll       + $lookupRecord.CustomerID		# example: CustomerID      : {066ADA42-D48D-4104-937F-6FDCFF48B4AB}
				$nvLrVirtualSubnetIdsAll  = $nvLrVirtualSubnetIdsAll  + $lookupRecord.VirtualSubnetID	# example: VirtualSubnetID : 641590
				$nvLrProviderAddressesAll = $nvLrProviderAddressesAll + $lookupRecord.ProviderAddress
				$nvLrCustomerAddressesAll = $nvLrCustomerAddressesAll + $lookupRecord.CustomerAddress
			}

			# find unique values
			$nvLrCustomerIds       = $nvLrCustomerIdsAll | sort | Get-Unique	
			$nvLrVirtualSubnetIds  = $nvLrVirtualSubnetIdsAll | sort | Get-Unique
			$nvLrProviderAddresses = $nvLrProviderAddressesAll | sort | Get-Unique
			$nvLrCustomerAddresses = $nvLrCustomerAddressesAll | sort | Get-Unique

			$nvLrCustomerIdsCount       = $nvLrCustomerIds.length
			$nvLrVirtualSubnetIdsCount  = $nvLrVirtualSubnetIds.length
			$nvLrProviderAddressesCount = $nvLrProviderAddresses.length
			$nvLrCustomerAddressesCount = $nvLrCustomerAddresses.length
			
			# How many CustomerRoutes are there?
			$nvCustomerRoute = Get-NetVirtualizationCustomerRoute
			$nvCustomerRouteCount = $nvCustomerRoute.length
			[array]$nvCrRoutingDomainIdsAll = @()
			[array]$nvCrVirtualSubnetIdsAll = @()
			foreach ($customerRoute in $nvCustomerRoute)
			{
				$nvCrRoutingDomainIdsAll = $nvCrRoutingDomainIdsAll + $customerRoute.RoutingDomainId
				$nvCrVirtualSubnetIdsAll = $nvCrVirtualSubnetIdsAll + $customerRoute.VirtualSubnetId
			}

			# find unique CustomerIDs
			$nvCrRoutingDomainIds      = $nvCrRoutingDomainIdsAll | sort | Get-Unique
			$nvCrRoutingDomainIdsCount = $nvCrRoutingDomainIds.length
			# find unique VirtualSubnetIDs
			$nvCrVirtualSubnetIds      = $nvCrVirtualSubnetIdsAll | sort | Get-Unique
			$nvCrVirtualSubnetIdsCount = $nvCrVirtualSubnetIdsAll.length

			# How many Provider Addresses are there?
			$nvPa  = Get-NetVirtualizationProviderAddress
			$nvPaCount = $nvPa.length
			[array]$nvPaProviderAddressesAll = @()
			foreach ($pa in $nvPa)
			{
				$nvPaProviderAddressesAll = $nvPaProviderAddressesAll + $pa.ProviderAddress
			}
			$nvPaProviderAddresses = $nvPaProviderAddressesAll | sort | Get-Unique

			# Build an array that contains just the Provider Addresses from other hosts
			# This array contains only PAs from this host: $nvPaProviderAddresses
			# This array contains all PAs in the HNV scenario: $nvLrProviderAddresses

			[array]$nvProviderAddressesOnOtherHosts = @()
			foreach ($lrpa in $nvLrProviderAddresses)
			{
				if ($nvPaProviderAddresses -notcontains $lrpa)
				{
					$nvProviderAddressesOnOtherHosts = $nvProviderAddressesOnOtherHosts + $lrpa
				}
			}


			"===================================================="		| Out-File -FilePath $OutputFile -append
			"HNV Hierarchical View" 									| Out-File -FilePath $OutputFile -append
			"  RoutingDomainID / VirtualSubnetID / VMs"					| Out-File -FilePath $OutputFile -append
			"===================================================="		| Out-File -FilePath $OutputFile -append
			"`n"														| Out-File -FilePath $OutputFile -append

			foreach ($rdid in $nvCrRoutingDomainIds)
			{
				# All of the following output is from the Get-NetVirtualizationCustomerRoute pscmdlet.
				
				# Show the RDID
				"`n"| Out-File -FilePath $OutputFile -append
				"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append	
				"Routing Domain ID        : " + $rdid 					| Out-File -FilePath $OutputFile -append	
				
				# Show the unique VSID(s) for this RDID
					# [array]$nvPaLocalVms = @()		#	$nvPaLocalVms = $nvPaLocalVms + $lr.VMName
					# [array]$nvPaRemoteVms = @()		#	$nvPaRemoteVms = $nvPaRemoteVms + $lr.VMName
				
				foreach ($vsid in $nvCrVirtualSubnetIds)
				{
					foreach ($cr in $nvCustomerRoute)
					{
						if (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID))
						{
							"`n" 										| Out-File -FilePath $OutputFile -append	
							"  VirtualSubnetID        :   " + $vsid 	| Out-File -FilePath $OutputFile -append	
							# Show the VMs per VSID [this host]
							foreach ($lr in $nvLookupRecord)
							{
								if ( (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID)) -and (($rdid -eq $lr.CustomerID) -and ($vsid -eq $lr.VirtualSubnetID)) )
								{
									# Only show the VMs with ProviderAddresses on this machine (IPs in this array: $nvPaProviderAddresses)
									foreach ($nvPaProviderAddress in $nvPaProviderAddresses)
									{
										if (($lr.ProviderAddress -eq $nvPaProviderAddress)  -and ($lr.VMName -ne "GW") -and ($lr.VMName -ne "GW-External") -and ($lr.VMName -ne "DHCPExt.sys"))
										{
											"      VM [THIS HOST]     :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
										}
									}						
								}
							}

							# Show the VMs per VSID [other hosts]
							foreach ($lr in $nvLookupRecord)
							{
								if ( (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID)) -and (($rdid -eq $lr.CustomerID) -and ($vsid -eq $lr.VirtualSubnetID)) )
								{
									# Only show the VMs with ProviderAddresses on this machine (IPs in this array: $nvPaProviderAddresses)
									foreach ($addr in $nvProviderAddressesOnOtherHosts)
									{
										if (($lr.ProviderAddress -eq $addr) -and ($lr.VMName -ne "GW") -and ($lr.VMName -ne "GW-External") -and ($lr.VMName -ne "DHCPExt.sys"))
										{
											"      VM                 :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress		 | Out-File -FilePath $OutputFile -append	
										}
									}
								}
							}

							foreach ($lr in $nvLookupRecord)
							{
								if ( (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID)) -and (($rdid -eq $lr.CustomerID) -and ($vsid -eq $lr.VirtualSubnetID)) )
								{
									# Only show the VMs with ProviderAddresses on this machine (IPs in this array: $nvPaProviderAddresses)
									foreach ($nvPaProviderAddress in $nvPaProviderAddresses)
									{
										if (($lr.ProviderAddress -eq $nvPaProviderAddress) -and ($lr.VMName -eq "GW"))
										{
											"      HNV GW (Internal)  :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
										}
										if (($lr.ProviderAddress -eq $nvPaProviderAddress) -and ($lr.VMName -eq "GW-External"))
										{
											"      HNV GW (External)  :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
										}
									}
								}
							}


							# Show the VMs per VSID [other hosts]
							foreach ($lr in $nvLookupRecord)
							{
								if ( (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID)) -and (($rdid -eq $lr.CustomerID) -and ($vsid -eq $lr.VirtualSubnetID)) )
								{
									# Only show the VMs with ProviderAddresses on this machine (IPs in this array: $nvPaProviderAddresses)
									foreach ($addr in $nvProviderAddressesOnOtherHosts)
									{
										if (($lr.ProviderAddress -eq $addr) -and ($lr.VMName -eq "GW"))
										{
											"      HNV GW (Internal)  :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
										}
										if (($lr.ProviderAddress -eq $addr) -and ($lr.VMName -eq "GW-External"))
										{
											"      HNV GW (External)  :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
										}
									}
								}
							}
							
						}
					}
				}

				"`n" 						| Out-File -FilePath $OutputFile -append	
				"  SCVMM DHCP Server" 		| Out-File -FilePath $OutputFile -append	
				# Show the SCVMM Software DHCP Server
				foreach ($vsid in $nvCrVirtualSubnetIds)
				{
					foreach ($cr in $nvCustomerRoute)
					{
						if (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID))
						{
							# Show the HNV Tenant Gateway (Internal)
							foreach ($lr in $nvLookupRecord)
							{
								if ( (($rdid -eq $cr.RoutingDomainID) -and ($vsid -eq $cr.VirtualSubnetID)) -and (($rdid -eq $lr.CustomerID) -and ($vsid -eq $lr.VirtualSubnetID)) )
								{
									if ($lr.VMName -eq "DHCPExt.sys")
									{
										"      SCVMM DHCP Server  :     " + $lr.VMName + " ; " + $lr.CustomerAddress + " ; " + $lr.ProviderAddress 		| Out-File -FilePath $OutputFile -append	
									}
								}
							}
						}
					}
				}	

			}
			"`n"			| Out-File -FilePath $OutputFile -append
			"`n"			| Out-File -FilePath $OutputFile -append
			"`n"			| Out-File -FilePath $OutputFile -append
			
		}
		else
		{
			"This server is not running WS2012 or WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Hyper-V Virtual Machine Management`" service is not running. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Hyper-V Virtual Machine Management`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}

CollectFiles -filesToCollect $outputFile -fileDescription "Hyper-V Networking Settings" -SectionDescription $sectionDescription


# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDW9I2Ow4GMmqOg
# UmxxgvyhyGB1pgJ18wA/XV4gUlQuDKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgweKgLzUJ
# /RZVf2Frx1b1Wc80dtGFc68S2kp4yYSd41cwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBALWsQFGtQMiUQJNUKL33wacqmzmeAgLsv+lBT9wMQQX9sATEVbT2MIxD
# NNQPD/bBbvWMjcKaH92QJZnAvC6UTVbaeYSEXKYScGVMk9BXMxGHWNlLfFfZ8jwZ
# l7koF6OYH5J60nlHJLI1teddURPgIR8xtSlFf8RDqmHVJyBH5wNNsEYviN1/ee+9
# L8ZPJWf2ESEfV/ghhmAEmVxfNDQfas/Wnt3HLB++Eq7oKnq+DUc6c+WMXx5YgA2c
# wPG8D4C26Uwbn8LtCBuJQ5lNLX8YEV+q5mjtp+3jtUs896en6iZCSczR+kwJsmhz
# 2yI+++rT38j6/POUcjmq0vcN712SReShghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgtxr7eI2FFZdFwBwzL5X6cTuHftnRDThxuUXVsni7fksCBmGB2SqX
# JBgTMjAyMTExMTExNjUzMzYuMjAyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFZn/x+Xyzq8kMAAAAAAVkwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE1WhcNMjIwNDExMTkwMjE1WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBB
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArnjEYclnxIdES00igGj0AboyujyARkK3
# xaBX+Y10i3a0w4/fNVhTj6xGwibFPB/MkQMFZpNzsvGUTL/XfTZ9GZ39HanCdjun
# JP3TK9kCZBAtnoP59oYHDCGLmut7+2YEl1sBcVnyovYkNzi3EGffQyvULwMUF2si
# PBs/6LZF0A5pLAiz/FCwx5kDPe/mP1UR3Crz6IzphwtyoqtgDA/44TnzfvVJPmSP
# Z/uq5Oh5NeFK8NzMpitWiQvdmfT4o0CdumnisfW1fKaaBdByBULPUT8TLw0Sy9nU
# WNXlA/qi8MxPxgCjsrNpi9PgjH7ExW9b7X/UydhpqhHxsudDGZNk4wIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFPbQqYVGvK365Osn14jCPLLpN2PnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAI2RVBLoD4GGt8Y4IBajcpy5Rrh6y2nPKf5kuWSHSkmY
# AmngRQOstayJ5gJ/ajKhzwqNUwL40cUVW8cutIyFadHkW1jqXdnpSv0hMFLPriPn
# BNFETy8ilCIdViNFU08ZHa2Kobmco/n6wPStkjjrg4U3Pift6sMk6lXsibUv+wDB
# 9f4YehziPmt+4C5BMVjzax1i+0czgtPHBX33u6GUWznagdql0VbUpe3q8zERedJf
# yyhB9R34z5ircnu51zpH3jUa7F93oDS95xXnomO+akKeDiNGSq4B7J/90qZBRpHV
# 8q8AsFECZmQBS1aKNL/cyR5C/+VS8dWjsY8XMn87fAkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0x
# NTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAqdssAjx+E7nxIJaulmde9cRmyEaCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TeMLjAiGA8y
# MDIxMTExMTE2MzM1MFoYDzIwMjExMTEyMTYzMzUwWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN4wuAgEAMAoCAQACAiZVAgH/MAcCAQACAhF9MAoCBQDlON2uAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPB+o9P5KuWdUoJBXwoX4L87nThTU
# 2S11U5IDYOUcrI26xNl/t9OaqJWivy8rytDWLl0U61OAH/Jw2SxZ3rdAwBepTDZW
# XANDRvwidcy0kqxaIjbS2bRgBXkoflMeDGktaA077jCjC5wtBW+J2FKoHzH3b8ed
# jKupzCxZBxWH66UxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVmf/H5fLOryQwAAAAABWTANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCA0V1V5
# HJKZbYhbTMY5V/PZ2CqUaTwlDFwbTTL1SJ9KQTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIAFYG8+/MOZ815LOYlPj50YD66P+qrv98qRSffqvE0PoMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFZn/x+Xyzq8kMA
# AAAAAVkwIgQgcLVW3bJKbJiHgsAuVX1ytoKPdrXTVrHf9HHAbN3hmOwwDQYJKoZI
# hvcNAQELBQAEggEAYiMOxf69VeTIE6z6DUs3pg2JSZ58EJn0UNdghQGBJM8/DGDv
# kWsQl4xRuEiH9cx5CmXrBfOguELfj0puWiy9vdUMHt0bxnnm3zylZaT3cN7Fn6gr
# YnRMRWmKTaqlCzzlJd0aJPEEBk+15JsnqjjgA80k7gL3hspwxu/xeSa77tgJcRvd
# abjvTr9WDjrM29RT40NAhjDHdNFnxWhp8csYDjDz0alsAYCJnSFF+n6Xy/ojUYTO
# ev/iRNGmp7Yd1BF22acaAaAyohB3n7kzalLk0d/aNUtXX277xUCwYoFwz/p+1XoL
# Bphw8y1WLdL9lblzZ74OCOyZt6pZjAlmHd7esg==
# SIG # End signature block
