﻿# This script has dependencies on utils_CTS and utils_DSD
#
param ( [Object[]] $instances, [switch]$CollectSqlDefaultDiagnosticXeLogs ,[switch]$CollectFailoverClusterDiagnosticXeLogs ,[switch]$CollectAlwaysOnDiagnosticXeLogs )  

# Certain properties of the SQL 2012 Failover Cluster and Always On XE logs can be customized.  
# The custom values are stored in registry values under key:
# HKLM:\Software\Microsoft\Microsoft SQL Server\<instance root>\MSSQLServer key
#
New-Variable LogFileRolloverCount		-Value "LogFileRolloverCount"   -Option ReadOnly
New-Variable LogMaxFileSizeINMBytes		-Value "LogMaxFileSizeINMBytes" -Option ReadOnly
New-Variable LogPath					-Value "LogPath"                -Option ReadOnly
New-Variable LogIsEnabled				-Value "LogIsEnabhled"          -Option ReadOnly


#
# Function : Get-XeDirectoryPathDefault
# -------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is used to find the path to the SQL Server errorlog for a given instance of SQL Server
# 
# Arguments:
#			$InstanceName
#			Function will find the default path to the SQL Server XE Health logs
# 
# Owner:
#			DanSha 
#
function Get-XeDirectoryPathDefault([string]$SqlInstance )
{
	$Error.Clear()           
	trap 
	{
		'[Get-XeDirectoryPathDefault] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error
	}

	return (Get-SqlServerLogPath -SqlInstance $SqlInstance)
}

#function CollectAndCompress-XeLogFiles ( [string]$XeLogDir, [bool] $IsClustered, [string]$instance, [string]$FileFilter )
#{     
#    trap 
#    {
#    	'[CollectAndCompress-XeLogFiles] : [ERROR] Trapped exception ...' | WriteTo-StdOut
#    	Report-Error 
#    }
#    
#    if ($FileFilter.Contains("SQLDIAG"))
#    {
#        $XeType = "Failover_Cluster_Diagnostics_health"
#    } 
#    elseif ($FileFilter.Contains("system_health"))
#    {
#        $XeType = "System_health"
#    }
#    elseif ($FileFilter.Contains("AlwaysOn"))
#    {
#        $XeType = "AlwaysOn_health"
#    }   
#    
#    if (Test-Path -Path $XeLogDir -Type "Container")
#    {
#        # Collect specified XE log files.  Have 90+ percent compression ratio so not worried about number and size
#        $XeLogfiles = get-childitem -Path (Join-Path $XeLogDir "*") -Include $FileFilter | foreach-object { Join-Path $_.DirectoryName $_.Name }
#        
#         if ($null -ne $XeLogfiles)
#         {
#            if (0 -lt $XeLogfiles.Count)
#    		{	
#				"[CollectAndCompress-XeLogFiles] : Found {0} {1} XE logs" -f $XeLogFiles.Count, $XeType | WriteTo-StdOut
#						
#    			# Compress and collect the XE files for this instance
#    			$ArchiveOut = "{0}_{1}_{2}_XeFiles.zip" -f $ComputerName, $instance, $XeType
#    			CompressCollectFiles -FilesToCollect $XeLogfiles -DestinationFileName $ArchiveOut -SectionDescription ("SQL Server {0} health files for instance: {1}" -f $XeType, $instance)
#    		}
#         }
#		 else
#		 {
#			"[CollectAndCompress-XeLogFiles] : Found 0 {1} XE logs" -f $XeType | WriteTo-StdOut
#		 }
#    }
#    else 
#	{
#		# Here is where we should do the check to see if this is a cluster and whether the drive is offline
#		"[CollectAndCompress-XeLogFiles] : Path to SQL XE logs: [{0}] for instance: {1} is invalid" -f $XeLogDir, $InstanceToCollect | WriteTo-StdOut
#			
#		# Check if drive that errorlogs are stored on is a cluster resource if the instance is clustered
#		if ($IsClustered)
#		{
#			$ParsedPath = $SqlErrorLogPath.Path.Split("\")
#			$ClusterDrive = $ParsedPath[0]
#			# Call function FindSqlDiskResource to see if the cluster resource is unavailable
#			#
#			if ($false -eq (FindSQLDiskResource($ClusterDrive)))
#			{
#				"[CollectAndCompress-XeLogFiles] : The cluster resource: [{0}] that the XE log files for instance: {1} are stored on is not available at this time" -f $ClusterDrive, $InstanceToCollect | WriteTo-StdOut
#			}
#		}
#	}
#    
#}

# Checks to see if customer set a custom diagnostics log location using ALTER SERVER CONFIGURATION DIAGNOSTICS LOG
function Get-XeDirectoryPathCustom ([string] $InstanceName)
{   
    trap 
    {
    	"[Get-XeDirectoryPathCustom] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
    }  

    if ($null -ne $InstanceName)
    {
    	$SqlRootKey =  Get-SqlInstanceRootKey $InstanceName   
        
        # First make sure we have a valid "root" key for this instance
        if (Test-Path -Path $SqlRootKey)
        {
            if ($null -ne $SqlRootKey)
            {
                 if ($true -eq (Test-RegistryValueExists (Join-Path -Path $SqlRootKey -ChildPath "MSSQLSERVER") $LogPath))
                 {
                    #Customer has modified the default XE log path with the ALTER SERVER 
                    [System.IO.Path]::GetDirectoryName((Get-ItemProperty (Join-Path $SqlRootKey "MSSQLSERVER")).$LogPath)
                 }
             }
         }
    } # if ($null -eq $InstanceName)
    else
    {
        '[Get-XeDirectoryPathCustom] : [ERROR] Required parameter -InstanceName not specified' | WriteTo-StdOut
    }
}


# This function retrieves the directory path for the Failover Cluster XE logs and Always On 
function Get-XeDirectoryPath ([string] $InstanceName)
{
    trap 
    {
    	"[Get-XeDirectoryPath] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
    
	# Validate required parameter was supplied
	if ($null -ne $InstanceName)
	{
	    # The XE log path can be customized using the ALTER SERVER DIAGNOSTICS command for FCI and AlwaysOn (but not default system health)
	    # so try to retrieve custom path first. If found, we will use that instead of the default path.
	    $XeLogPath = Get-XeDirectoryPathCustom $InstanceName
	    
	    if ($null -eq $XeLogPath )
	    {
	        # Custom path not set; retrieve default XE log path
	        $XeLogPath = Get-XeDirectoryPathDefault $InstanceName
	    }
    }
	else
	{
		'[Get-XeDirectoryPath] : [ERROR] Required parameter -InstanceName was not supplied' | WriteTo-StdOut
	}
    return $XeLogPath
}

function Collect-SqlXeGeneralHealthSessionLogs ([string]$InstanceName, [bool]$IsClustered)
{
    $Error.Clear()           
    trap 
    {
    	"[Collect-SqlXeHealthSessionLogs] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
    }
    
	if ($null -ne $InstanceName)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            # Post progress message to dialog visible to user
        	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthalLogDesc + ": " + $InstanceName)

            # SQL Health sessions are always in default log folder. Not configurable
            $XeHealthSessionLogDir = Get-XeDirectoryPathDefault $InstanceName 
            
            if ($null -ne $XeHealthSessionLogDir)
            {
                # Valid path?
                if ($true -eq (Test-Path -Path $XeHealthSessionLogDir))
                {
                    $FciFiles = @()
    				$FciFiles = Copy-FileSql -SourcePath $XeHealthSessionLogDir `
                             -FileFilters @('system_health*.XEL') `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_SYSTEM_HEALTH_XELOGS  `
                             -InstanceName $InstanceName `
    						 -SectionDescription ("'General System Health logs for instance {0}" -f $InstanceName) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_system_health_XeLogs.zip" -f $ComputerName, $InstanceName)
                }
                else
                {
                    # Does the log path reference a cluster disk that is offline from this node at this time?
                    if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceName -PathToTest $XeHealthSessionLogDir))
        	        {
        	            "[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] No Sql General System Health logs will be collected. Path to General Health XE logs: [{0}] for instance: [{1}] is invalid" -f $XeHealthSessionLogDir, $InstanceName | WriteTo-StdOut
        	        } 
                }
            }
            else
            {
                '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Get-XeDirectoryPathDefault returned a null path to Sql Server general system health Xe logs' | WriteTo-StdOut
            }
        
        } #if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        else
        {
            '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Required parameter -IsClustered was not specified or contains an incorrect value' | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceName)
    else
    {
        '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut
    }
	
}

#
# Function : Collect-SqlFailoverClusterDiagnosticXeLogs
# -----------------------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function enumerates the Failover Cluster Diagnostic Xel files and calls the CollectAndCompress-XeLogFiles
#           to collect the log files from the customer machine.
#           Note that there can be quite a large number of these files present on a server at any given time.
#           We do not limit the number or age of the files we collect because they compress at better than 90% compression ratio
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
function Collect-SqlFailoverClusterDiagnosticXeLogs ( [string]$InstanceName, [bool]$IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[Collect-SqlXeFailoverClusterLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }
    
	# Post progress message to dialog visible to user
	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeFailoverClusterlHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeFailoverClusterlHealthLogsDesc + ": " + $InstanceName)

    if ($null -ne $InstanceName) 
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            $XeFailoverClusterLogPath = Get-XeDirectoryPath $InstanceName 

        	if ($null -ne $XeFailoverClusterLogPath)
            {
                if ($true -eq (Test-Path -Path $XeFailoverClusterLogPath))
            	{
                    # FCI XEL Filename Format: <COMPUTER_NAME>_<INSTANCE_NAME>_SQLDIAG_*  
                    # Actual Example:          215126NEWNODE2_MSSQLSERVER_SQLDIAG_0_129719944456780000.xel
                    # Search Mask:             *<INSTANCE_NAME>_SQLDIAG*.XEL
                    #
                    # These files are created on a shared drive (cluster resource) and the file name includes the name of the node where the file was created.  
                    # As such, we cannot include the COMPUTER_NAME in the -FileFilter argument as this part of the file name will be determined by 
                    # the NETBIOS computer name of the node SQL Server was executing on at the time the file was created
                   	                    # Enumerate and then copy the files
                                                
    				$FciFiles = @()
    				$FciFiles = Copy-FileSql -SourcePath $XeFailoverClusterLogPath `
                             -FileFilters @("*_{0}_SQLDIAG*.XEL" -f $InstanceName) `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_FAILOVER_CLUSTER_XELOGS `
                             -InstanceName $InstanceName `
    						 -SectionDescription ("'Failover Cluster Health logs for instance {0}" -f $InstanceName) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_FailoverCluster_health_XeLogs.zip" -f $ComputerName, $InstanceName)
                             
                   # Report outcome of collection to stdout.log
                   if (($null -ne $FciFiles) -and (0 -lt $FciFiles.Count))
                   {
                        "[Collect-SqlXeFailoverClusterHealthLogs] : [INFO] [{0}] Sql Failover Cluster diagnostic logs collected for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
                   }
                   else
                   {
                        "[Collect-SqlXeFailoverClusterHealthLogs] : [INFO] No Sql Failover Cluster diagnostic logs collected for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
                   }
                   
            	} #if ($true -eq (Test-Path -Path $XeFailoverClusterLogPath))
                else
                {
        			if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceName -PathToTest $XeFailoverClusterLogPath))
        	        {
        	            "[Collect-SqlXeFailoverClusterHealthLogs] : [ERROR] No SQL Sql Failover Cluster diagnostic logs will be collected. Path to failover cluster diagnositcs logs: [{0}] for instance: {1} is invalid" -f $XeFailoverClusterLogPath, $InstanceName | WriteTo-StdOut
        	        }      
                }
            
            } # if ($null -ne $XeFailoverClusterLogPath)
            else
            {
                "[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Get-XeDirectoryPath returned a null log path for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
            }
            
            
        }  # if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        else
        {
            '[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Required parameter -IsClustered was not specified' | WriteTo-StdOut
        }

    } # if ($null -ne $InstanceName)
    else
    {
        '[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut
    }
}

#
# Function : Collect-SqlAlwaysOnDiagnosticXeLogs
# ----------------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function drives logic to collect the AlwaysOn Diagnostic logs
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
# Sample AlwaysOn file name:
#           AlwaysOn_health_0_129736303650760000.xel
#
function Collect-SqlAlwaysOnDiagnosticXeLogs( [string] $Instance, [bool] $IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[Collect-SqlAlwaysOnDiagnosticXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }  
    
    If ($null -ne $Instance)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
        	# Post progress message to dialog visible to user
        	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthalLogDesc + ": " + $Instance)
            
        	$XeAlwaysOnLogPath = Get-XeDirectoryPath -InstanceName $Instance 
            
        	if ($null -ne $XeAlwaysOnLogPath)
            {
                if ($true -eq (Test-Path -Path $XeAlwaysOnLogPath))
            	{
                                
                    # Enumerate and then copy the files
    				$Files = @()
    				$Files = Copy-FileSql -SourcePath $XeAlwaysOnLogPath `
                             -FileFilters @('AlwaysOn_health*.XEL') `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ALWAYSON_XELOGS `
                             -InstanceName $Instance `
    						 -SectionDescription ("'AlwaysOn Health logs for instance {0}" -f $Instance) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_AlwaysOn_health_XeLogs.zip" -f $ComputerName, $Instance)
                    
                    # Report number of logs enumerated and copied
                    if (($null -ne $Files) -and (0 -lt $Files.Count))
                    {
                        "[Collect-SqlXeAlwaysOnHealthLogs] : [INFO] Collected [{0}] AlwaysOn diagnostic logs for instance: [{1}]" -f $Files.Count, $Instance | WriteTo-StdOut
                    }
                    else
                    {
                        "[Collect-SqlXeAlwaysOnHealthLogs] : [INFO] No AlwaysOn diagnostic logs were collected for instance: [{0}]" -f $Instance | WriteTo-StdOut
                    }
                    
                }
                else
                {
                    # Does the log path reference a cluster disk that is offline from this node at this time?
                    if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $Instance -PathToTest $XeAlwaysOnLogPath))
        	        {
        	            "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] No SQL Server AlwaysOn diagnostic logs will be collected. Path to AlwaysOn Diagnostic logs: [{0}] for instance: [{1}] is invalid" -f $XeAlwaysOnLogPath, $Instance | WriteTo-StdOut
        	        }
                      
                }
                
            } # if ($null -ne $XeAlwaysOnLogPath)
            else
            {
                "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Get-XeDirectoryPath returned a null path to the AlwaysOn Xe logs for instance: [{0}]" -f $Instance | WriteTo-StdOut
            }
            
        } # if ($null -ne $IsClustered)
        else
        {
            "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Required parameter -IsClustered was not specified" | WriteTo-StdOut
        }
        
    } # If ($null -ne $Instance)
    else
    {
        "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Required parameter -Instance was not specified" | WriteTo-StdOut
    }
}

#
# Function : Collect-SqlXeLogs
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that drives Xe log collection based on switch parameters that the script is called with
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
function Collect-SqlXeLogs ( [string] $InstanceName, [bool] $IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[DC-GetSqlXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }    
    
    if ($null -ne $InstanceName)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            # Collect Sql Server General/Default Diagnostic Session Xe Log files?    
            if ($true -eq $CollectSqlDefaultDiagnosticXeLogs)
            {
                # Collect the Health Session XE files that are on by default
                Collect-SqlXeGeneralHealthSessionLogs -InstanceName $InstanceName -IsClustered $IsClustered
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql Default Health Session Xe log collection bypassed. $CollectSqlHealthXeLogs: {0}' -f $CollectSqlDefaultDiagnosticXeLogs | WriteTo-StdOut
            }
            
            # Collect failover cluster diagnostic Xe log files?
            if ($true -eq $CollectFailoverClusterDiagnosticXeLogs)
            {
                # Collect the SQL Server failover cluster diagnostic log files
                Collect-SqlFailoverClusterDiagnosticXeLogs -InstanceName $InstanceName -IsClustered $IsClustered 
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql Failover Cluster Diagnostic Xe log collection bypassed. $CollectFailoverClusterDiagnosticXeLogs: {0}' -f $CollectFailoverClusterDiagnosticXeLogs | WriteTo-StdOut
            }
            
            # Collect Always On Diagnostic Xe logs?
            if ($true -eq $CollectAlwaysOnDiagnosticXeLogs)
            {
                # Collect the Always On diagnostic log files
                Collect-SqlAlwaysOnDiagnosticXeLogs -Instance $InstanceName -IsClustered $IsClustered 
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql AlwaysOn Diagnostic Xe log collection bypassed. $CollectAlwaysOnHealthXeLogs: {0}' -f $CollectAlwaysOnHealthXeLogs | WriteTo-StdOut
            }
                
        } # if ($null =ne $IsClustered)
        else
        {
            '[Collect-SqlXeLogs] : [ERROR] Required parameter -IsClustered was not secified' | WriteTo-StdOut
        }
        
    } # if ($null -eq $InstanceName)
    else
    {
          '[Collect-SqlXeLogs] : [ERROR] Required parameter -InstanceName was not secified' | WriteTo-StdOut
    }
}
	
$Error.Clear()           
trap 
{
   	'[DC_GetSqlXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
   	Report-Error
}  

Import-LocalizedData -BindingVariable xeHealthLogsCollectorStrings

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
    
    if (($null -ne $instances) -and (0 -lt $instances.count))
    {
        foreach ($instance in $instances)
        {
			# Only try to collect these logs on SQL Sever 2012 or later
            if ($global:SQL:SQL_VERSION_MAJOR_SQL2012 -le $instance.SqlVersionMajor)
			{
				if ('DEFAULT' -eq $instance.InstanceName.ToUpper() ) {$instance.InstanceName = 'MSSQLSERVER'}
                
				Collect-SqlXeLogs -InstanceName $instance.InstanceName -IsClustered $instance.IsClustered 
			}
			else
			{
				"[DC-GetSqlXeLogs] : No SQL Server system health logs were collected for instance {0}" -f $instance.InstanceName | WriteTo-StdOut
				"[DC-GetSqlXeLogs] : SQL instance must be SQL Server 2012 or later.  Major version for instance {0} is {1}" -f $instance.InstanceName, $instance.SqlVersionMajor | WriteTo-StdOut
			}
            
        } # foreach ($instance in $instances)
        
    } # if (($null -ne $instances) -and (0 -lt $instances.count))
    else
    {
        'DC-GetSqlXeLogs] : [ERROR] Enumerate-SqlInstances returned a null instance array' | WriteTo-StdOut
    }
}
else
{
    "[DC-GetSqlXeLogs] : [INFO] SQL Server is not installed on computer: [{0}]" -f $env:ComputerName | WriteTo-StdOut
}
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBgUR5BtKJlfxrT
# SdSA54EretEqPcqeE2sy0oQRjlveb6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgJASPyA8M
# 6ISHcMKvW5AcWW26nRJm/i6lUhTt9ke5hgUwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAA85VShTLDcNFjo/RmCGWxIoL/ztmIlytfv3EfQ648w9ptWObuxf+c8h
# icRpGWL6zMdS2YlJuhyqBbgGxpgTvEsiD1JgV62kP03LF3fWauRyAEgJ9xYIZRpz
# IDWeFly7MDxsklQFqM5v0IabYvUAQ2RLHQX5lLsovbwWLAaHZCexfW/xfbR9vQ4D
# sRwF7EbK9YkyASasod30jWa2p+UIKYmmaFuWBBHeCi+HA+o0wv5L3el2luClpTP+
# /a+syS+XfhoIT4+dWprTW3TSNaERpif8OLwxkSE6jqrY9LAuy3HVh29MxdZ9ekQN
# 8M0mrpI32YtX2uPp4SDFKvIloYlqIjGhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgnnqADm52CKZ83bpBkBzkx+sOK9IrAqKIMkG0eonZNvwCBmGB81FC
# ixgTMjAyMTExMTExNjUzMzUuMjY5WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjRE
# MkYtRTNERC1CRUVGMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFfw65lVuVTWOwAAAAAAV8wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE5WhcNMjIwNDExMTkwMjE5WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjREMkYtRTNERC1CRUVG
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvD15+YLZZD25prDuTiDEdJIISgkuTbYV
# MBoXyNhsAyRALoNAXRY+ciF4szURFO5D0VZuCV/SZdsN3YqN7NE2XPnfJwkhF6IZ
# RA6fDm93hOCMtTEvXuDcrQw/ac2Fj8vI/3wyX/jRf3Tl6ANuIid1l20eINvXF9jX
# tru/WP2jea5z4wKAW31875TgIM1SkwwxAkWv/1CVThh0lrCNvIp8rcu2+p+reW+A
# rT8emGIO1flyHdt4Y0EqjApJNeF+3ynC5dA+ui61aAHk9mYA3xdmEAKjiNaL9rTO
# AAklwGqhe9LoietZwf8SqL+pVqPxWznr9n/qRphlm7/WZLMufkQAswIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFCXs6dOVzSuBnsV3uqUMWC5hNTj1MB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAA6C19kslhJuwTdbved3SEuepCodIWXaykfHN5fEzi4l
# Pa4BWT9ItXPOO9l6ZQMF4550p5cbyFy2mumhAylTeBuw1SdRoN6wNyZH54QsLBhr
# 5UGRQKqwgYmZCUPC4PA1rruTIIQ/I9bn1i7bD92M2vA1ZKO25HB9QWgOSNjIOOdc
# PSOiyLrurEmBbytGqOX1rraEbOXOAT5pUtNPkiErnPZfrYumHyP1/heO0I+fJ4Uo
# WaAFYc9jUdtuNQd+D3VK0IvG54fYuNmhARNY4n6nESWJxfBU/kHTCVaSJq7C6Det
# MqcNvlYpRvaWWydCBp6BX4xCMwjsrq/6ym+wyBGM+WEwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjREMkYtRTNERC1C
# RUVGMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQD6B9KqN0Cd04URpc5DIEJ26mZCh6CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TemYzAiGA8y
# MDIxMTExMTE4MjUzOVoYDzIwMjExMTEyMTgyNTM5WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN6ZjAgEAMAoCAQACAhmmAgH/MAcCAQACAhGFMAoCBQDlOPfjAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAC9H6gd3ZXIkpylekA/E1yodWwQuM
# ssJZ8CKNYcY8mshShATaGtPg/gSpoGor01m0X68hP6mdiTZG5s0CC6lbJZw/aUGp
# iVAmMq9/aJDG9U8XtcW5BsQArSISPeWoZSCL77ShHzGDvl+4+Y+xvuYPtiehsuFS
# 1eumEq8rw02uhggxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAV/DrmVW5VNY7AAAAAABXzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBPsqpp
# lqc5OX2n0x8sK/yF/6veLVqQK8OgiYb5WuCxFTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EINDNerUrEawu6PSzOS2ueWEhGqZvCnltUZzoG7qGCUxcMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFfw65lVuVTWOwA
# AAAAAV8wIgQgNxgLhTCH8BGZ/vBPDqC9fMgwgnRuvmp1gkW5dFglufowDQYJKoZI
# hvcNAQELBQAEggEAa5JHh/4HMsP3GkahxagIokG/sc+fhUhDaRj3p2BtX5PyKtDi
# ReTrnT+pnJrmmQp2mb9LX6srmkS3rh6dka8goSAwIZt7xIT2F654DUWX/02WKrO3
# ITzL0/X/IJZ4jRJ4kbakOaeQ3f3E72r4X8lGFZoocMVnXoCqkuDQLd0tNOmrKbdh
# G9GGZR1mE8kUAdxGe6oXrKe064g+kpaRH036UCjcYmgs+4fjsFa4o7tSNsQit6jO
# KwoExAlMfdIAT771q0B+Nmff8ZyxrnSEfcftcoQSSByDl31/KpAEIfzh4BDotsAQ
# Onig7/npwPlO1k+IzSnm+qX8g4LD9TvWqcOYVQ==
# SIG # End signature block
