﻿#************************************************
# DC_CSVinfo.ps1
# 2019-03-17 WalterE added Trap #_# , 2020-09-28 add skipCsvSMB

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}


$FileName = $Env:COMPUTERNAME + "_CSVInfo.HTM"

Function OpenSection ([string] $name="", $xpath="/Root", $title="")
{
	[System.Xml.XmlElement] $rootElement=$xmlDoc.SelectNodes($xpath).Item(0)
	[System.Xml.XmlElement] $section = $xmlDoc.CreateElement("Section")
	$section.SetAttribute("name",$name)
	$rootElement.AppendChild($section)
	AddXMLElement -ElementName "SectionTitle" -value $title -xpath "/Root/Section[@name=`'$name`']"

}

Function AddXMLElement ([string] $ElementName="Item", 
						[string] $Value,
						[string] $AttributeName="name", 
						[string] $attributeValue,
						[string] $xpath="/Root")
{
	[System.Xml.XmlElement] $rootElement=$xmlDoc.SelectNodes($xpath).Item(0)
	if ($rootElement -ne $null) { 
		[System.Xml.XmlElement] $element = $xmlDoc.CreateElement($ElementName)
		if ($attributeValue.lenght -ne 0) {$element.SetAttribute($AttributeName, $attributeValue)}
		if ($Value.lenght -ne 0) {$element.innerXML = $Value}
		$rootElement.AppendChild($element)
	} else {
		"Error. Path $xpath returned a null value. Current XML document: `n" + $xmlDoc.OuterXml
	}
}

Function TestCSV ($SharedVolume)
{
	#This function perform 2 tests: 
	#   1. Checks the state of a ClusterSharedVolume.
	#   2. Checks if volume is accessible locally
	#   3. Checks if volume is accessible via SMB
	
	# 1st test:
	if ($SharedVolume.State -ne "Online")
	{
		$AlertMessage = "Cluster Shared Volume <b>" + $SharedVolume.Name + "</b> has <b><font color=`'red`'>" + $SharedVolume.State + "</font></b> state."
		AddXMLAlert -AlertType $ALERT_WARNING -AlertCategory "CSV State" -AlertMessage $AlertMessage
	} else {
		# 2nd test:
		$LocalCSVStoragePath = $SharedVolume.SharedVolumeInfo[0].FriendlyVolumeName
		if (-not (Test-Path $LocalCSVStoragePath))
		{
			$AlertMessage = "Cluster Shared Volume <b>" + $SharedVolume.Name + "</b> is Online, but access to the path <b>$LocalCSVStoragePath</b> returns an error. This usually indicates a network communication problem or that the resource is in <i>Maintenance Mode</i>."
			$AlertRecommendation = ""
			if ($SharedVolume.OwnerNode.Name -ne $Env:COMPUTERNAME) 
			{
				$AlertRecommendation = "The " + $SharedVolume.Name + " is now owned by node <b>" + $SharedVolume.OwnerNode.Name.ToUpper() + "</b>. Please check if there is SMB connectivity between nodes $Env:COMPUTERNAME and " + $SharedVolume.OwnerNode.Name.ToUpper() + "<br/>"  
				$AlertRecommendation += "Common ways to test SMB connectivity are: Running <b>net view \\" + $SharedVolume.OwnerNode.Name +"</b>, <b>net view \\{IP Address of " + $SharedVolume.OwnerNode.Name.ToUpper() +"}</b> or using explorer locally to try to access the shares on remote node." 
			}
			
			AddXMLAlert -AlertType $ALERT_WARNING -AlertCategory "Local CSV Access" -AlertMessage $AlertMessage -alertRecommendation $AlertRecommendation
			
			$InformationCollected = New-Object PSObject
			$InformationCollected | Add-Member -MemberType NoteProperty -Name "Cluster Shared Volume" -Value $SharedVolume.Name
			$InformationCollected | Add-Member -MemberType NoteProperty -Name "Local CSV Path" -Value $LocalCSVStoragePath
			$InformationCollected | Add-Member -MemberType NoteProperty -Name "Current Owner" -Value $SharedVolume.OwnerNode.Name.ToUpper()
			
			Write-GenericMessage -RootCauseID "RC_CSVLocalAccess" -InformationCollected $InformationCollected -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/12/16/troubleshooting-redirected-access-on-a-cluster-shared-volume-csv.aspx" -Visibility 4 -Component "FailoverCluster" -SupportTopicsID 8003 -SDPFileReference $FileName
			
			if ($CSVLocalAccessIssueDisplay -ne "") 
			{
				$CSVVolumeNames += " and "
				$CSVLocalAccessIssueDisplay += "<br/><br/>"
			}
			$CSVLocalAccessIssueDisplay += $AlertMessage
			$CSVVolumeNames += $SharedVolume.Name 
		}
		
		if ($CSVLocalAccessArray -ne $null) 
		{
			Update-DiagRootCause -id "RC_CSVLocalAccess" -Detected $true
		}
		
		# 3rd test:
		#_# adding knob to skipt 3rd test
		if ($Global:skipCsvSMB -ne $true) {
		if ($SharedVolume.OwnerNode.Name -ne $Env:COMPUTERNAME) {
			"Testing accessing shares via SMB..."
			$CSVCommunicationNetworks = GetInternalIPAdressesForCommunicationWithNode $SharedVolume.OwnerNode.Name
			$CSVStorageShare = $SharedVolume.Id + "-" + $SharedVolume.SharedVolumeInfo[0].VolumeOffset
			$RC_CSVNetworkAccess = $false
			Foreach ($CSVNetwork in $CSVCommunicationNetworks) 
			{
				
				"Testing $IPAdress..."
				$IPAdress = $CSVNetwork.Address
				$ShareURL = "\\$IPAdress\$CSVStorageShare" + "$"
				
				#It is expected that user receive Access Denied from share
				#Since it does not have permissions for user access the share. 
	
				$Error.Clear
				&{
					"Test" | Out-File $ShareURL -ErrorAction SilentlyContinue
				}
				trap 
				{
					$CSVVolumeNames = ""
					$ExceptionToAccessShare = $_.Exception.GetType().FullName
					if ($ExceptionToAccessShare -ne "System.UnauthorizedAccessException") 
					{
						$ExceptionToAccessShare += ": " + $_.Exception.Message
						$AlertMessage = "Unable to access <b>" + $SharedVolume.Name + "</b> volume on node <b>" + $SharedVolume.OwnerNode.Name.ToUpper() + "</b> via SMB using address \\$IPAdress. The exception to access the share is <b><font color=`'red`'>$ExceptionToAccessShare</font></b>"
						$AlertRecommendation = ""
						
						if ($SharedVolume.OwnerNode.Name -ne $Env:COMPUTERNAME) 
						{
							$NetworkName = $CSVNetwork.Name
							$AlertRecommendation = "The " + $SharedVolume.Name + " is now owned by node <b>" + $SharedVolume.OwnerNode.Name + "</b>. Please check if there is SMB connection between node $Env:COMPUTERNAME and " + $SharedVolume.OwnerNode.Name.ToUpper() + "<br/>"  
							$AlertRecommendation += "Common ways to test SMB connectivity are: Running <b>net view \\" + $IPAdress +"</b> or using explorer locally to try to access the shares on remote node.<br/>"
							$AlertRecommendation += "Please also check if the <i>Client For Microsoft Networks</i> is enabled on $Env:COMPUTERNAME. Also check if the <i>File and Print Sharing for Microsoft Networks</i> is enabled on " + $SharedVolume.OwnerNode.Name + "'s <b>$NetworkName</b> network connection."
						}
						
						AddXMLAlert -AlertType $ALERT_WARNING -AlertCategory "Remote CSV Access" -AlertMessage $AlertMessage -AlertRecommendation $AlertRecommendation 
						if ($CSVNetworkAccessIssueDisplay -ne "") 
						{
							$CSVVolumeNames += " and "
							$CSVNetworkAccessIssueDisplay += "<br/><br/>"
						}
						
						$InformationCollected = @{"Shared volume" = $SharedVolume.Name; "Current Owner" = $SharedVolume.OwnerNode.Name; "State" = $SharedVolume.State; "Volume Path" = $SharedVolume.SharedVolumeInfo[0].Partition.Name; "CSV Network Name" = $CSVNetwork.Name}
						Write-GenericMessage -RootCauseID "RC_CSVNetworkAccess" -InformationCollected $InformationCollected -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/12/16/troubleshooting-redirected-access-on-a-cluster-shared-volume-csv.aspx" -Visibility 4 -Component "FailoverCluster" -SupportTopicsID 8003 -SDPFileReference $FileName
						$RC_CSVNetworkAccess = $true
						
						$CSVNetworkAccessIssueDisplay += $AlertMessage
						$CSVVolumeNames += $SharedVolume.Name
					}

					continue; 
				}
			}
			if ($RC_CSVNetworkAccess) 
			{
				Update-DiagRootCause -id "RC_CSVNetworkAccess" -Detected $true
			}

		} #_# and 3rd test
		}
	}
}

Function GetInternalIPAdressesForCommunicationWithNode ([string] $NodeName)
{
	Return Get-ClusterNetworkInterface | Where-Object {($_.Network.Role -ne 0) -and ($_.Node -eq $NodeName)}
}

Function AddXMLAlert([int] $AlertType = $ALERT_INFORMATION, 
					[string] $AlertCategory="",
					[string] $AlertMessage="",
					[string] $AlertRecommendation="",
					[int] $AlertPriority=50)
{
	switch ($AlertType)	{
		$ALERT_INFORMATION {$strAlertType = "Information"}
		$ALERT_WARNING {$strAlertType = "Warning"}
		$ALERT_ERROR {$strAlertType = "Error"}
	}
	# Try to find the <Alerts> node. Create it if does not exist.	
	[System.Xml.XmlElement] $alertsElement=$xmlDoc.SelectNodes("/Root/Alerts").Item(0)
	if ($alertsElement -eq $null) {
		AddXMLElement -ElementName "Alerts"
	}
	
	$XMLAlert =   "<AlertType>$strAlertType</AlertType>" +
                  "<AlertCategory>$AlertCategory</AlertCategory>" +
                  "<AlertMessage>$AlertMessage</AlertMessage>" +
	              "<AlertPriority>$AlertPriority</AlertPriority>"
	if ($AlertRecommendation.Length -ne 0) {
		$XMLAlert += "<AlertRecommendation>$AlertRecommendation</AlertRecommendation>"
	}
    	
	AddXMLElement -ElementName "Alert" -xpath "/Root/Alerts" -value $XMLAlert 
}

Function GenerateHTMLFile(){
	$HTMLFilename = $PWD.Path + "\" + $Env:COMPUTERNAME + "_CSVInfo.HTM"
	$XSLFilename = $Env:COMPUTERNAME + "_CSVInfo.XSL"
	$XMLFilename = $Env:TEMP + "\CSVInfo.XML"
	$xmlDoc.Save($XMLFilename)
	[xml] $XSLContent = (EmbeddedXSL $XSLFilename)
	$XSLObject = New-Object system.Xml.Xsl.XslTransform
	$XSLObject.Load($XSLContent)
	$XSLObject.Transform($XMLFilename, $HTMLFilename)
	Remove-Item $XMLFilename
	return $HTMLFilename
    "Output saved at $HTMLFilename"
}

Function EmbeddedXSL($XSLFilename){
	$PSScriptName = $myInvocation.ScriptName
	
	Get-Content $PSScriptName | ForEach-Object {
		if ($insideXSL) {
			if ($_ -eq "}") {$insideXSL = $true}
		}
		if ($insideXSL) {
			$XSLContent += $_.Substring(1)
		}
		if ($_ -eq "Function EmbeddedXSL(){"){$insideXSL = $true}
	}
	return $XSLContent
}

#region: MAIN
Set-Variable -Name ALERT_INFORMATION -Value 1 -Option Constant
Set-Variable -Name ALERT_WARNING -Value 2 -Option Constant
Set-Variable -Name ALERT_ERROR -Value 3 -Option Constant

$ClusterKey="HKLM:\Cluster"
$xmlDoc = [xml] "<?xml version=""1.0""?><Root/>"
$ClusterKey="HKLM:\Cluster"

if (($OSVersion.Build -ge 7600) -and (Test-Path $ClusterKey)) 
{

	Import-LocalizedData -BindingVariable ScriptVariables
	Write-DiagProgress -activity $ScriptVariables.ID_ClusterCSVD -status $ScriptVariables.ID_ClusterCSVDesc
	
	Import-Module FailoverClusters
	
	$SharedVolumes = Get-ClusterSharedVolume
	
	if ($SharedVolumes -ne $null) {
		AddXMLElement -ElementName "Title" -Value $Env:COMPUTERNAME
		$CurrentDate = Get-Date
		AddXMLElement -ElementName "TimeField" -Value $CurrentDate 
		
		OpenSection -name "SharedVolumes" -title "Cluster Shared Volumes"
		AddXMLElement -attributeValue "CSV Enabled" -Value "True" -xpath "/Root/Section[@name=`'SharedVolumes`']"
		$RC_CSVMaint = $false
		foreach ($SharedVolume in $SharedVolumes) 
		{
			$sharedVolumeID = $SharedVolume.Id
			AddXMLElement -ElementName "SubSection" -attributeValue $SharedVolumeID -xpath "/Root/Section[@name=`'SharedVolumes`']"
			$csvVolumeSectionTitle = "Volume: " + $SharedVolume.Name
			AddXMLElement -ElementName "SectionTitle" -value $csvVolumeSectionTitle  -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "State" -value $SharedVolume.State -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "Current Owner" -value $SharedVolume.OwnerNode.Name -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "ID" -value $SharedVolume.Id -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "Volume Name" -value $SharedVolume.SharedVolumeInfo[0].FriendlyVolumeName -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			$VolumeSize = '{0:N2}' -f ($SharedVolume.SharedVolumeInfo[0].Partition.Size / 1024 /1024)
			$VolumeSize += " MB"
			AddXMLElement -attributeValue "Volume Size" -value $VolumeSize  -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "Volume Path" -value $SharedVolume.SharedVolumeInfo[0].Partition.Name -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "Maintenance mode" -value $SharedVolume.SharedVolumeInfo[0].MaintenanceMode -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			AddXMLElement -attributeValue "Redirected access" -value $SharedVolume.SharedVolumeInfo[0].RedirectedAccess -xpath "/Root/Section/SubSection[@name=`'$SharedVolumeId`']"
			if ($SharedVolume.SharedVolumeInfo[0].MaintenanceMode) 
			{
				$AlertMessage = "Shared Volume <b> " + $SharedVolume.Name + "</b> owned by node <b>" + $SharedVolume.OwnerNode.Name + "</b> is now on Maintenance Mode"
				$InformationCollected = @{"Shared volume" = $SharedVolume.Name; "Current Owner" = $SharedVolume.OwnerNode.Name; "State" = $SharedVolume.State; "Volume Path" = $SharedVolume.SharedVolumeInfo[0].Partition.Name}
				
				AddXMLAlert -AlertType $ALERT_INFORMATION -AlertCategory "Maintenance Mode" -AlertMessage $AlertMessage -AlertPriority 60
				Write-GenericMessage -RootCauseID "RC_CSVMaint" -Component "FailoverCluster" -InformationCollected $InformationCollected -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/12/16/troubleshooting-redirected-access-on-a-cluster-shared-volume-csv.aspx" -Visibility 4 -SupportTopicsID 8003 -SDPFileReference $FileName
				
				$RC_CSVMaint = $true
			}
			
			if ($SharedVolume.SharedVolumeInfo[0].RedirectedAccess) 
			{
				$AlertMessage = "Shared Volume <b>" + $SharedVolume.Name + "</b> owned by node <b>" + $SharedVolume.OwnerNode.Name + "</b> has now Redirected Access enabled"
				AddXMLAlert -AlertType $ALERT_INFORMATION -AlertCategory "Redirected Access" -AlertMessage $AlertMessage -AlertPriority 60
				
				$RC_CSVRedirect = $true
				$InformationCollected = @{"Shared volume" = $SharedVolume.Name; "Current Owner" = $SharedVolume.OwnerNode.Name}
				Write-GenericMessage -RootCauseID "RC_CSVRedirect" -Component "FailoverCluster" -InformationCollected $InformationCollected -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/12/16/troubleshooting-redirected-access-on-a-cluster-shared-volume-csv.aspx" -Visibility 4 -SupportTopicsID 8003 -SDPFileReference $FileName
				
			}			
			TestCSV $SharedVolume	
		}
		
		if ($RC_CSVMaint     -ne $null )  { Update-DiagRootCause -id "RC_CSVMaint" -Detected $RC_CSVMaint}
		if ($RC_CSVRedirect  -ne $null)   { Update-DiagRootCause -id "RC_CSVRedirect" -Detected $RC_CSVRedirect }
		
		$fileToCollect = GenerateHTMLFile
		CollectFiles -filesToCollect $fileToCollect -fileDescription "CSV Information" -sectionDescription "Cluster Shared Volumes"
        
	} else {
		"There are no Cluster Shared Volumes on this cluster" | writeto-stdout
	}
} else {
	"Cluster registry key does not exist or OS does not support CSVs" | WriteTo-StdOut
}

#endregion: MAIN

Function EmbeddedXSL(){
#<?xml version="1.0"?>
#<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
#<xsl:output method="html" />
#<xsl:template match="/Root">
#<html dir="ltr" xmlns:v="urn:schemas-microsoft-com:vml" gpmc_reportInitialized="false">
#<head>
#<!-- Styles -->
#  <style type="text/css">
#    body    { background-color:#FFFFFF; border:1px solid #666666; color:#000000; font-size:68%; font-family:MS Shell Dlg; margin:0,0,10px,0; word-break:normal; word-wrap:break-word; }
#
#    table   { font-size:100%; table-layout:fixed; width:100%; }
#
#    td,th   { overflow:visible; text-align:left; vertical-align:top; white-space:normal; }
#
#    .title  { background:#FFFFFF; border:none; color:#333333; display:block; height:24px; margin:0px,0px,-1px,0px; padding-top:4px; position:relative; table-layout:fixed; width:100%; z-index:5; }
#
#    .he0_expanded    { background-color:#FEF7D6; border:1px solid #BBBBBB; color:#3333CC; cursor:hand; display:block; font-family:Verdana; font-size:110%; font-weight:bold; height:2.25em; margin-bottom:-1px; margin-left:0px; margin-right:0px; padding-left:8px; padding-right:5em; padding-top:4px; position:relative; width:100%;
#    filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=1,StartColorStr='#FEF7D6',EndColorStr='white');}
#
#    .he3_expanded { background-color:#C0D2DE; border:1px solid #BBBBBB; color:#000000; display:block; font-family:MS Shell Dlg; font-size:100%; height:2.25em; margin-bottom:-1px; font-weight:bold; margin-left:0px; margin-right:0px; padding-left:4px; padding-right:5em; padding-top:4px; position:relative; width:100%; }
#
#    .he1old { background-color:#A0BACB; border:1px solid #BBBBBB; color:#000000; cursor:hand; display:block; font-family:MS Shell Dlg; font-size:100%; font-weight:bold; height:2.25em; margin-bottom:-1px; margin-left:10px; margin-right:0px; padding-left:8px; padding-right:5em; padding-top:4px; position:relative; width:100%; }
#
#    .he1    { background-color:#FEF7D6; border:1px solid #BBBBBB; color:#3333CC; cursor:hand; display:block; font-family:Segoe UI, Verdana; font-size:110%; font-weight:bold; height:2.25em; margin-bottom:-1px; margin-left:0px; margin-right:0px; padding-left:8px; padding-right:5em; padding-top:4px; position:relative; width:100%; }
#
#    .he2    { background-color:#C0D2DE; border:1px solid #BBBBBB; color:#000000; cursor:hand; display:block; font-family:MS Shell Dlg; font-size:100%; font-weight:bold; height:2.25em; margin-bottom:-1px; margin-left:10px; margin-right:0px; padding-left:8px; padding-right:5em; padding-top:4px; position:relative; width:100%; }
#
#    .he2b    { background-color:#C0D2DE; border:1px solid #BBBBBB; color:#000000; cursor:hand; display:block; font-family:MS Shell Dlg; font-size:100%; font-weight:bold; height:2.25em; margin-bottom:-1px; margin-left:10px; margin-right:0px; padding-left:8px; padding-right:5em; padding-top:4px; position:relative; width:100%; }
#
#    .he4i   { background-color:#F9F9F9; border:1px solid #BBBBBB; color:#000000; display:block; font-family:MS Shell Dlg; font-size:100%; margin-bottom:-1px; margin-left:15px; margin-right:0px; padding-bottom:5px; padding-left:12px; padding-top:4px; position:relative; width:100%; }
#
#    DIV .expando { color:#000000; text-decoration:none; display:block; font-family:MS Shell Dlg; font-size:100%; font-weight:normal; position:absolute; right:10px; text-decoration:underline; z-index: 0; }
#
#    .info4 TD, .info4 TH              { padding-right:10px; width:25%;}
#
#    .infoFirstCol                     { padding-right:10px; width:20%; }
#    .infoSecondCol                     { padding-right:10px; width:80%; }
#
#
#    .subtable, .subtable3             { border:1px solid #CCCCCC; margin-left:0px; background:#FFFFFF; margin-bottom:10px; }
#
#    .subtable TD, .subtable3 TD       { padding-left:10px; padding-right:5px; padding-top:3px; padding-bottom:3px; line-height:1.1em; width:10%; }
#
#    .subtable TH, .subtable3 TH       { border-bottom:1px solid #CCCCCC; font-weight:normal; padding-left:10px; line-height:1.6em;  }
#
#    .explainlink:hover      { color:#0000FF; text-decoration:underline; }
#
#    .filler { background:transparent; border:none; color:#FFFFFF; display:block; font:100% MS Shell Dlg; line-height:8px; margin-bottom:-1px; margin-left:43px; margin-right:0px; padding-top:4px; position:relative; }
#
#    .container { display:block; position:relative; }
#
#    .rsopheader { background-color:#A0BACB; border-bottom:1px solid black; color:#333333; font-family:MS Shell Dlg; font-size:130%; font-weight:bold; padding-bottom:5px; text-align:center;
#    filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0,StartColorStr='#FFFFFF',EndColorStr='#A0BACB')}
#
#    .rsopname { color:#333333; font-family:MS Shell Dlg; font-size:130%; font-weight:bold; padding-left:11px; }
#
#    #uri    { color:#333333; font-family:MS Shell Dlg; font-size:100%; padding-left:11px; }
#
#    #dtstamp{ color:#333333; font-family:MS Shell Dlg; font-size:100%; padding-left:11px; text-align:left; width:30%; }
#
#    #objshowhide { color:#000000; cursor:hand; font-family:MS Shell Dlg; font-size:100%; font-weight:bold; margin-right:0px; padding-right:10px; text-align:right; text-decoration:underline; z-index:2; word-wrap:normal; }
#
#
#    @media print {
#
#    #objshowhide{ display:none; }
#
#    body    { color:#000000; border:1px solid #000000; }
#
#    .title  { color:#000000; border:1px solid #000000; }
#
#    .he0_expanded    { color:#000000; border:1px solid #000000; }
#
#    }
#
#    v\:* {behavior:url(#default#VML);}
#
#  </style>
#<!-- Script 1 -->
#
#<script language="vbscript" type="text/vbscript">
#<![CDATA[
#<!--
#'================================================================================
#' String "strShowHide(0/1)"
#' 0 = Hide all mode.
#' 1 = Show all mode.
#strShowHide = 1
#
#'Localized strings
#strShow = "show"
#strHide = "hide"
#strShowAll = "show all"
#strHideAll = "hide all"
#strShown = "shown"
#strHidden = "hidden"
#strExpandoNumPixelsFromEdge = "10px"
#
#
#Function IsSectionHeader(obj)
#    IsSectionHeader = (obj.className = "he0_expanded") Or (obj.className = "he1_expanded") Or (obj.className = "he1") Or (obj.className = "he2") Or (obj.className = "he2g") Or (obj.className = "he2c") or (obj.className = "he3") Or (obj.className = "he4") Or (obj.className = "he4h") Or (obj.className = "he5") Or (obj.className = "he5h")  or (obj.className = "he4_expanded")
#End Function
#
#
#Function IsSectionExpandedByDefault(objHeader)
#    IsSectionExpandedByDefault = (Right(objHeader.className, Len("_expanded")) = "_expanded")
#End Function
#
#
#' strState must be show | hide | toggle
#Sub SetSectionState(objHeader, strState)
#    ' Get the container object for the section.  It's the first one after the header obj.
#
#    i = objHeader.sourceIndex
#    Set all = objHeader.parentElement.document.all
#    While (all(i).className <> "container")
#        i = i + 1
#    Wend
#
#    Set objContainer = all(i)
#
#    If strState = "toggle" Then
#        If objContainer.style.display = "none" Then
#            SetSectionState objHeader, "show"
#        Else
#            SetSectionState objHeader, "hide"
#        End If
#
#    Else
#        Set objExpando = objHeader.children(1)
#
#        If strState = "show" Then
#            objContainer.style.display = "block"
#            rem objExpando.innerText = strHide
#            rem objExpando.innerHTML = "<v:group id=" & chr(34) & "Show" & chr(34) & " class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:15px;height:15px;vertical-align:middle" & chr(34) & " coordsize=" & chr(34) & "100,100" & chr(34) & " alt=" & chr(34) & "Hide" & chr(34) & "><v:shape class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:100; height:100; z-index:0" & chr(34) & " fillcolor=" & chr(34) & "green" & chr(34) & " strokecolor=" & chr(34) & "green" & chr(34) & "><v:path v=" & chr(34) & "m 30,50 l 70,50 x e" & chr(34) & " /></v:shape></v:group>"
#            objExpando.innerHTML =   "<v:group class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:15px;height:15px;vertical-align:middle" & chr(34) & " coordsize=" & chr(34) & "100,100" & chr(34) & " alt=" & chr(34) & "Show" & chr(34) & "><v:rect " & chr(34) & " stroked=" & chr(34) & "False" & chr(34) & "fillcolor=" & chr(34) & "#808080" & chr(34) & " style=" & chr(34) & "top:47;left:25;width:50;height:5" & chr(34) & " /></v:group>"
#        ElseIf strState = "hide" Then
#            objContainer.style.display = "none"
#            rem objExpando.innerText = strShow
#            rem objExpando.outerHTML = "<v:group class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:15px;height:15px;vertical-align:middle" & chr(34) & " coordsize=" & chr(34) & "100,100" & chr(34) & " alt=" & chr(34) & "Show" & chr(34) & "><v:shape class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:100; height:100; z-index:0" & chr(34) & " fillcolor=" & chr(34) & "black" & chr(34) & " strokecolor=" & chr(34) & "red" & chr(34) & "><v:path v=" & chr(34) & "m 99,1 l 1,1 50,50 x e" & chr(34) & " /></v:shape></v:group>"
#            objExpando.innerHTML =   "<v:group class=" & chr(34) & "vmlimage" & chr(34) & " style=" & chr(34) & "width:15px;height:15px;vertical-align:middle" & chr(34) & " coordsize=" & chr(34) & "100,100" & chr(34) & " alt=" & chr(34) & "Show" & chr(34) & "><v:rect fillcolor=" & chr(34) & "#808080" & chr(34) & " stroked=" & chr(34) & "False" & chr(34) & " style=" & chr(34) & "top:47;left:25;width:50;height:5" & chr(34) & " /><v:rect fillcolor=" & chr(34) & "#808080" & chr(34) & " stroked=" & chr(34) & "False" & chr(34) & " style=" & chr(34) & "top:25;left:47;width:5;height:50" & chr(34) & " /></v:group>"
#        End If
#
#    End If
#End Sub
#
#
#Sub ShowSection(objHeader)
#    SetSectionState objHeader, "show"
#End Sub
#
#
#Sub HideSection(objHeader)
#    SetSectionState objHeader, "hide"
#End Sub
#
#
#Sub ToggleSection(objHeader)
#    SetSectionState objHeader, "toggle"
#End Sub
#
#
#'================================================================================
#' When user clicks anywhere in the document body, determine if user is clicking
#' on a header element.
#'================================================================================
#Function document_onclick()
#    Set strsrc    = window.event.srcElement
#
#    While (strsrc.className = "sectionTitle" Or strsrc.className = "expando" Or strsrc.className = "vmlimage")
#        Set strsrc = strsrc.parentElement
#    Wend
#
#    ' Only handle clicks on headers.
#    If Not IsSectionHeader(strsrc) Then Exit Function
#
#    ToggleSection strsrc
#
#    window.event.returnValue = False
#End Function
#
#'================================================================================
#' link at the top of the page to collapse/expand all collapsable elements
#'================================================================================
#Function objshowhide_onClick()
#    Set objBody = document.body.all
#    Select Case strShowHide
#        Case 0
#            strShowHide = 1
#            objshowhide.innerText = strShowAll
#            For Each obji In objBody
#                If IsSectionHeader(obji) Then
#                    HideSection obji
#                End If
#            Next
#        Case 1
#            strShowHide = 0
#            objshowhide.innerText = strHideAll
#            For Each obji In objBody
#                If IsSectionHeader(obji) Then
#                    ShowSection obji
#                End If
#            Next
#    End Select
#End Function
#
#'================================================================================
#' onload collapse all except the first two levels of headers (he0, he1)
#'================================================================================
#Function window_onload()
#    ' Only initialize once.  The UI may reinsert a report into the webbrowser control,
#    ' firing onLoad multiple times.
#    If UCase(document.documentElement.getAttribute("gpmc_reportInitialized")) <> "TRUE" Then
#
#        ' Set text direction
#        Call fDetDir(UCase(document.dir))
#
#        ' Initialize sections to default expanded/collapsed state.
#        Set objBody = document.body.all
#
#        For Each obji in objBody
#            If IsSectionHeader(obji) Then
#                If IsSectionExpandedByDefault(obji) Then
#                    ShowSection obji
#                Else
#                    HideSection obji
#                End If
#            End If
#        Next
#
#        objshowhide.innerText = strShowAll
#
#        document.documentElement.setAttribute "gpmc_reportInitialized", "true"
#    End If
#End Function
#
#
#
#
#'================================================================================
#' When direction (LTR/RTL) changes, change adjust for readability
#'================================================================================
#Function document_onPropertyChange()
#    If window.event.propertyName = "dir" Then
#        Call fDetDir(UCase(document.dir))
#    End If
#End Function
#Function fDetDir(strDir)
#    strDir = UCase(strDir)
#    Select Case strDir
#        Case "LTR"
#            Set colRules = document.styleSheets(0).rules
#            For i = 0 To colRules.length -1
#                Set nug = colRules.item(i)
#                strClass = nug.selectorText
#                If nug.style.textAlign = "right" Then
#                    nug.style.textAlign = "left"
#                End If
#                Select Case strClass
#                    Case "DIV .expando"
#                        nug.style.Left = ""
#                        nug.style.right = strExpandoNumPixelsFromEdge
#                    Case "#objshowhide"
#                        nug.style.textAlign = "right"
#                End Select
#            Next
#        Case "RTL"
#            Set colRules = document.styleSheets(0).rules
#            For i = 0 To colRules.length -1
#                Set nug = colRules.item(i)
#                strClass = nug.selectorText
#                If nug.style.textAlign = "left" Then
#                    nug.style.textAlign = "right"
#                End If
#                Select Case strClass
#                    Case "DIV .expando"
#                        nug.style.Left = strExpandoNumPixelsFromEdge
#                        nug.style.right = ""
#                    Case "#objshowhide"
#                        nug.style.textAlign = "left"
#                End Select
#            Next
#    End Select
#End Function
#
#'================================================================================
#'When printing reports, if a given section is expanded, let's says "shown" (instead of "hide" in the UI).
#'================================================================================
#Function window_onbeforeprint()
#    For Each obji In document.all
#        If obji.className = "expando" Then
#            If obji.innerText = strHide Then obji.innerText = strShown
#            If obji.innerText = strShow Then obji.innerText = strHidden
#        End If
#    Next
#End Function
#
#'================================================================================
#'If a section is collapsed, change to "hidden" in the printout (instead of "show").
#'================================================================================
#Function window_onafterprint()
#    For Each obji In document.all
#        If obji.className = "expando" Then
#            If obji.innerText = strShown Then obji.innerText = strHide
#            If obji.innerText = strHidden Then obji.innerText = strShow
#        End If
#    Next
#End Function
#
#'================================================================================
#' Adding keypress support for accessibility
#'================================================================================
#Function document_onKeyPress()
#    If window.event.keyCode = "32" Or window.event.keyCode = "13" Or window.event.keyCode = "10" Then 'space bar (32) or carriage return (13) or line feed (10)
#        If window.event.srcElement.className = "expando" Then Call document_onclick() : window.event.returnValue = false
#        If window.event.srcElement.className = "sectionTitle" Then Call document_onclick() : window.event.returnValue = false
#        If window.event.srcElement.id = "objshowhide" Then Call objshowhide_onClick() : window.event.returnValue = false
#    End If
#End Function
#
#-->
#]]>
#</script>
#
#<!-- Script 2 -->
#
#<script language="javascript"><![CDATA[
#<!--
#function getExplainWindowTitle()
#{
#        return document.getElementById("explainText_windowTitle").innerHTML;
#}
#
#function getExplainWindowStyles()
#{
#        return document.getElementById("explainText_windowStyles").innerHTML;
#}
#
#function getExplainWindowSettingPathLabel()
#{
#        return document.getElementById("explainText_settingPathLabel").innerHTML;
#}
#
#function getExplainWindowExplainTextLabel()
#{
#        return document.getElementById("explainText_explainTextLabel").innerHTML;
#}
#
#function getExplainWindowPrintButton()
#{
#        return document.getElementById("explainText_printButton").innerHTML;
#}
#
#function getExplainWindowCloseButton()
#{
#        return document.getElementById("explainText_closeButton").innerHTML;
#}
#
#function getNoExplainTextAvailable()
#{
#        return document.getElementById("explainText_noExplainTextAvailable").innerHTML;
#}
#
#function getExplainWindowSupportedLabel()
#{
#        return document.getElementById("explainText_supportedLabel").innerHTML;
#}
#
#function getNoSupportedTextAvailable()
#{
#        return document.getElementById("explainText_noSupportedTextAvailable").innerHTML;
#}
#
#function showExplainText(srcElement)
#{
#    var strSettingName = srcElement.getAttribute("gpmc_settingName");
#    var strSettingPath = srcElement.getAttribute("gpmc_settingPath");
#    var strSettingDescription = srcElement.getAttribute("gpmc_settingDescription");
#
#    if (strSettingDescription == "")
#    {
#                strSettingDescription = getNoExplainTextAvailable();
#    }
#
#    var strSupported = srcElement.getAttribute("gpmc_supported");
#
#    if (strSupported == "")
#    {
#        strSupported = getNoSupportedTextAvailable();
#    }
#
#    var strHtml = "<html>\n";
#    strHtml += "<head>\n";
#    strHtml += "<title>" + getExplainWindowTitle() + "</title>\n";
#    strHtml += "<style type='text/css'>\n" + getExplainWindowStyles() + "</style>\n";
#    strHtml += "</head>\n";
#    strHtml += "<body>\n";
#    strHtml += "<div class='head'>" + strSettingName +"</div>\n";
#    strHtml += "<div class='path'><b>" + getExplainWindowSettingPathLabel() + "</b><br/>" + strSettingPath +"</div>\n";
#    strHtml += "<div class='path'><b>" + getExplainWindowSupportedLabel() + "</b><br/>" + strSupported +"</div>\n";
#    strHtml += "<div class='info'>\n";
#    strHtml += "<div class='hdr'>" + getExplainWindowExplainTextLabel() + "</div>\n";
#    strHtml += "<div class='bdy'>" + strSettingDescription + "</div>\n";
#    strHtml += "<div class='btn'>";
#    strHtml += getExplainWindowPrintButton();
#    strHtml += getExplainWindowCloseButton();
#    strHtml += "</div></body></html>";
#
#    var strDiagArgs = "height=360px, width=630px, status=no, toolbar=no, scrollbars=yes, resizable=yes ";
#    var expWin = window.open("", "expWin", strDiagArgs);
#    expWin.document.write("");
#    expWin.document.close();
#    expWin.document.write(strHtml);
#    expWin.document.close();
#    expWin.focus();
#
#    //cancels navigation for IE.
#    if(navigator.userAgent.indexOf("MSIE") > 0)
#    {
#        window.event.returnValue = false;
#    }
#
#    return false;
#}
#-->
#]]>
#</script>
#
#</head>
#
#<body>
#
#	<table class="title" cellpadding="0" cellspacing="0">
#	<tr><td colspan="2" class="rsopheader">Cluster Shared Volume Information</td></tr>
#	<tr><td colspan="2" class="rsopname">Machine name: <xsl:value-of select="Title"/></td></tr>
#	<tr><td id="dtstamp">Data collected on: <xsl:value-of select="TimeField"/></td><td><div id="objshowhide" tabindex="0"></div></td></tr>
#	</table>
#	<div class="filler"></div>
#
#  <xsl:if test="./Alerts/Alert">
#    <div class="container">
#      <div class="he0_expanded">
#        <span class="sectionTitle" tabindex="0">Alerts</span>
#        <a class="expando" href="#"></a>
#      </div>
#      <div class="container">
#        <xsl:for-each select="./Alerts/Alert">
#          <xsl:sort select="AlertPriority" order="descending" data-type="number"/>
#          <div class="he2b">
#            <span class="sectionTitle" tabindex="0">
#              <xsl:choose>
#                <xsl:when test="AlertType = 'Information'">
#                  <v:group id="Inf1" class="vmlimage" style="width:15px;height:15px;vertical-align:middle" coordsize="100,100" title="Information">
#                    <v:oval class="vmlimage" style="width:100;height:100;z-index:0" fillcolor="white" strokecolor="#336699" />
#                    <v:line class="vmlimage" style="z-index:1" from="50,15" to="50,25" strokecolor="#336699" strokeweight="3px" />
#                    <v:line class="vmlimage" style="z-index:2" from="50,35" to="50,80" strokecolor="#336699" strokeweight="3px" />
#                  </v:group>
#                </xsl:when>
#                <xsl:when test="AlertType = 'Warning'">
#                  <v:group class="vmlimage" style="width:15px;height:15px;vertical-align:middle" coordsize="100,100" title="Warning">
#                    <v:shape class="vmlimage" style="width:100; height:100; z-index:0" fillcolor="yellow" strokecolor="#C0C0C0">
#                      <v:path v="m 50,0 l 0,99 99,99 x e" />
#                    </v:shape>
#                    <v:rect class="vmlimage" style="top:35; left:45; width:10; height:35; z-index:1" fillcolor="black" strokecolor="black">
#                    </v:rect>
#                    <v:rect class="vmlimage" style="top:85; left:45; width:10; height:5; z-index:1" fillcolor="black" strokecolor="black">
#                    </v:rect>
#                  </v:group>
#                </xsl:when>
#                <xsl:when test="AlertType = 'Error'">
#                  <v:group class="vmlimage" style="width:15px;height:15px;vertical-align:middle" coordsize="100,100" title="Error">
#                    <v:oval class="vmlimage" style='width:100;height:100;z-index:0' fillcolor="red" strokecolor="red">
#                    </v:oval>
#                    <v:line class="vmlimage" style="z-index:1" from="25,25" to="75,75" strokecolor="white" strokeweight="3px">
#                    </v:line>
#                    <v:line class="vmlimage" style="z-index:2" from="75,25" to="25,75" strokecolor="white" strokeweight="3px">
#                    </v:line>
#                  </v:group>
#                </xsl:when>
#                <xsl:when test="AlertType = 'Memory Dump'">
#                  <v:group class="vmlimage" style="width:14px;height:14px;vertical-align:middle" coordsize="100,100" title="Memory Dump">
#                    <v:roundrect class="vmlimage" arcsize="0.3" style="width:100;height:100;z-index:0" fillcolor="#008000" strokecolor="#66665B" />
#                    <v:line class="vmlimage" style="z-index:2" from="50,15" to="50,60" strokecolor="white" strokeweight="3px" />
#                    <v:shape class="vmlimage" style="width:100; height:100; z-index:0" fillcolor="white" strokecolor="white">
#                      <v:path v="m 50,85 l 75,60 25,60 x e" />
#                    </v:shape>
#                  </v:group>
#                  <xsl:text>&#160;</xsl:text>
#                </xsl:when>
#              </xsl:choose>
#              <xsl:value-of select="AlertType"/>
#            </span>
#            <a class="expando" href="#"></a>
#          </div>
#          <div class="container">
#            <div class="he4i">
#              <table cellpadding="0" class="info0">
#                <tr>
#                  <td class="infoFirstCol">Category: </td>
#                  <td class="infoSecondCol">
#                    <xsl:value-of disable-output-escaping="yes" select="AlertCategory"/>
#                  </td>
#                  <td></td>
#                </tr>
#                <tr>
#                  <td class="infoFirstCol">Message: </td>
#                  <td class="infoSecondCol">
#                    <xsl:copy-of select="AlertMessage"/>
#                  </td>
#                  <td></td>
#                </tr>
#                <xsl:if test="AlertRecommendation">
#                  <tr>
#                    <td class="infoFirstCol">Recommendation: </td>
#                    <td class="infoSecondCol">
#                      <xsl:copy-of select="AlertRecommendation"/>
#                    </td>
#                    <td></td>
#                  </tr>
#                </xsl:if>
#              </table>
#            </div>
#          </div>
#        </xsl:for-each>
#      </div>
#    </div>
#  </xsl:if>
#	<div class="filler"></div>
#	
#	<xsl:for-each select="./Section">
#
#	<div class="he0_expanded"><span class="sectionTitle" tabindex="0"><xsl:value-of select="SectionTitle"/></span><a class="expando" href="#"></a></div>
#	
#		<div class="container"><div class="he4i"><table cellpadding="0" class="info4" >
#		<tr><td></td><td></td><td></td><td></td><td></td></tr>
#		<xsl:for-each select="./Item">
#		<xsl:variable name="pos" select="position()" />
#		<xsl:variable name="mod" select="($pos mod 2)" />
#		<tr><td><xsl:value-of select="@name"/></td><td colspan="4"><xsl:value-of select="."/></td></tr>
#		</xsl:for-each>
#		</table>
#		<xsl:for-each select="./SubSection">
#			<div class="container">
#			<div class="he3_expanded"><span class="sectionTitle" tabindex="0"><xsl:value-of select="SectionTitle/@name"/><xsl:text> </xsl:text><a name="{SectionTitle}"><xsl:value-of select="SectionTitle"/></a></span><a class="expando" href="#"></a></div>
#			<div class="container"><div class="he4i"><table cellpadding="0" class="info4">
#				<tr><td></td><td></td><td></td><td></td><td></td></tr>
#				<xsl:for-each select="./Item">
#				<xsl:variable name="pos" select="position()" />
#				<xsl:variable name="mod" select="($pos mod 2)" />
#          <xsl:choose>
#            <xsl:when test="@name='State'">
#              <tr>
#                <td>
#                  <xsl:value-of select="@name"/>
#                </td>
#                <td colspan="4">
#                  <xsl:choose>
#                    <xsl:when test=". = 'Online'">
#                      <v:group class="vmlimage" style="width:14px;height:14px;vertical-align:middle" coordsize="100,100" title="Memory Dump">
#                        <v:roundrect class="vmlimage" arcsize="20" style="width:100;height:100;z-index:0" fillcolor="#00D700" strokecolor="#66665B" />
#                        <v:line class="vmlimage" style="z-index:2" from="50,50" to="50,85" strokecolor="white" strokeweight="3px" />
#                        <v:shape class="vmlimage" style="width:100; height:100; z-index:0" fillcolor="white" strokecolor="white">
#                          <v:path v="m 50,15 l 75,60 25,60 x e" />
#                        </v:shape>
#                      </v:group>
#                      <xsl:text>&#160;</xsl:text>
#                    </xsl:when>
#                    <xsl:when test=". = 'Offline'">
#                      <v:group class="vmlimage" style="width:14px;height:14px;vertical-align:middle" coordsize="100,100" title="Memory Dump">
#                        <v:roundrect class="vmlimage" arcsize="20" style="width:100;height:100;z-index:0" fillcolor="#EC0000" strokecolor="#66665B" />
#                        <v:line class="vmlimage" style="z-index:2" from="50,15" to="50,60" strokecolor="white" strokeweight="3px" />
#                        <v:shape class="vmlimage" style="width:100; height:100; z-index:0" fillcolor="white" strokecolor="white">
#                          <v:path v="m 50,85 l 75,60 25,60 x e" />
#                        </v:shape>
#                      </v:group>
#                      <xsl:text>&#160;</xsl:text>
#                    </xsl:when>
#                  </xsl:choose>
#                  <xsl:value-of disable-output-escaping="yes" select="."/>
#                </td>
#                <td></td>
#              </tr>
#            </xsl:when>
#            <xsl:otherwise>
#              <tr>
#                <td>
#                  <xsl:value-of select="@name"/>
#                </td>
#                <td colspan="4">
#                  <xsl:value-of disable-output-escaping="yes" select="."/>
#                </td>
#                <td></td>
#              </tr>
#            </xsl:otherwise>
#          </xsl:choose>
#				</xsl:for-each>
#				</table>
#			</div></div>
#					</div>
#		</xsl:for-each>
#
#    </div></div>
#	<div class="filler"></div>
#
#	</xsl:for-each>
#
#</body>
#</html>
#</xsl:template>
#</xsl:stylesheet>
}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA/+GCe3KoRugCY
# 46MHJK3e0NBroKHq/g20uMziP8TPiqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgAcpNXsnm
# fQDRles/GFWknOFixQdDYlf0lTqCHo2XCuAwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADmvEpnpuT3cxT1kh0mboMvV7dSl9IsO4nBnvtmBj7PLXPDkSQkvawPT
# KUE4KRgAOK/CqpVSzouDAji6NyIt3aORN5i/OisAER0VaFJjJ+xLe4PATBFC9g8Y
# Nakr/ElkxiO5c+Yq3Bd0hlVxgWdlyYwtOVH9kmkDlhRKx5edlVBfAZY2IM91IFgX
# /V24Nl5fI3uavFrGIa472IfK50UR+VdeELYtmSOsY20JnUty53DqmSJ2GNajJMA0
# ei4fEio/QG1LvRg9rFOZgtnhkHpE9BzviH7MtHBJu5Qelhq6q54mFqX71FfiM+4y
# 4dqsJYPQxe36JrdhMWzSEfuawAQlouehghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg+YZKWNxA9Lk6UeKtFSfBt+KZ0++v9r0cd+NbJydxnEACBmGB2SqX
# KhgTMjAyMTExMTExNjUzMzYuMjk5WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFZn/x+Xyzq8kMAAAAAAVkwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE1WhcNMjIwNDExMTkwMjE1WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBB
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArnjEYclnxIdES00igGj0AboyujyARkK3
# xaBX+Y10i3a0w4/fNVhTj6xGwibFPB/MkQMFZpNzsvGUTL/XfTZ9GZ39HanCdjun
# JP3TK9kCZBAtnoP59oYHDCGLmut7+2YEl1sBcVnyovYkNzi3EGffQyvULwMUF2si
# PBs/6LZF0A5pLAiz/FCwx5kDPe/mP1UR3Crz6IzphwtyoqtgDA/44TnzfvVJPmSP
# Z/uq5Oh5NeFK8NzMpitWiQvdmfT4o0CdumnisfW1fKaaBdByBULPUT8TLw0Sy9nU
# WNXlA/qi8MxPxgCjsrNpi9PgjH7ExW9b7X/UydhpqhHxsudDGZNk4wIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFPbQqYVGvK365Osn14jCPLLpN2PnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAI2RVBLoD4GGt8Y4IBajcpy5Rrh6y2nPKf5kuWSHSkmY
# AmngRQOstayJ5gJ/ajKhzwqNUwL40cUVW8cutIyFadHkW1jqXdnpSv0hMFLPriPn
# BNFETy8ilCIdViNFU08ZHa2Kobmco/n6wPStkjjrg4U3Pift6sMk6lXsibUv+wDB
# 9f4YehziPmt+4C5BMVjzax1i+0czgtPHBX33u6GUWznagdql0VbUpe3q8zERedJf
# yyhB9R34z5ircnu51zpH3jUa7F93oDS95xXnomO+akKeDiNGSq4B7J/90qZBRpHV
# 8q8AsFECZmQBS1aKNL/cyR5C/+VS8dWjsY8XMn87fAkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0x
# NTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAqdssAjx+E7nxIJaulmde9cRmyEaCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TeMLjAiGA8y
# MDIxMTExMTE2MzM1MFoYDzIwMjExMTEyMTYzMzUwWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN4wuAgEAMAoCAQACAiZVAgH/MAcCAQACAhF9MAoCBQDlON2uAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPB+o9P5KuWdUoJBXwoX4L87nThTU
# 2S11U5IDYOUcrI26xNl/t9OaqJWivy8rytDWLl0U61OAH/Jw2SxZ3rdAwBepTDZW
# XANDRvwidcy0kqxaIjbS2bRgBXkoflMeDGktaA077jCjC5wtBW+J2FKoHzH3b8ed
# jKupzCxZBxWH66UxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVmf/H5fLOryQwAAAAABWTANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDZBf+2
# tqlW/Zc73Pv0mRaAhTQD1wsxEJIuE+O2H97BgzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIAFYG8+/MOZ815LOYlPj50YD66P+qrv98qRSffqvE0PoMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFZn/x+Xyzq8kMA
# AAAAAVkwIgQgcLVW3bJKbJiHgsAuVX1ytoKPdrXTVrHf9HHAbN3hmOwwDQYJKoZI
# hvcNAQELBQAEggEANUmRegaVKy4J1UZ2OY9ZwMiTTz1b94e9P3G/HxV0aA2B8lnW
# oW7C2CuCEdZAq/DaiuWyEjiKBi5Rpi6yzfpzglGtPa3+lwYX4SaJv+TtgvqVp+RL
# /KNOrPX8vx3Ki8fsUjUzWkw8IO+9k1sZCqJ38HU2PCMtqFTtWYPAz3i/EEoOsb8O
# R4Q3QkQTkCOf30+pYAPsdDDUn579bW0P7Qr1SKOmU0cxWYEqtlX0iyZ9KtCRsxBQ
# ZAtjFDEdpvmkq2Oue2GXw+xKzRUDmYGGA3vgclIFbIc6IZitt/Zgd0sjggDkVsHK
# F4mJKO0vf4ppP/QH58LPBnzC+vL6L5d8B2MRhw==
# SIG # End signature block
