<# Name: tss_TestShareConn.ps1
# last edit:  2021-03-07
# Purpose: For troubleshooting Share not accessible by normal domain user after a File server reboot
#>

<#
.SYNOPSIS
For troubleshooting Share not accessible by normal domain user after a File server reboot

.DESCRIPTION
The script helps troubleshooting the issue: Share not accessible by normal domain user after a File server reboot 
It should be invoked by a Scheduled Task that starts right after each server reboot.
The script impersonates a normal domain user, maps a drive letter to a \\FileServer\FileShare and checks if the user has access to files located on (subfolder Folder_Perm on that) share
Depending on the result (SUCCESS / FAILURE), it will
 - on SUCCESS: stop persistent data collection and discard boot-data by using:      TSS OFF Discard
 - on FAILURE: stop persistent data collection and save all TSS boot-data by using: TSS OFF
Independent of results (good case / failure case) it will start a new TSS data collection at next reboot

You can modify the section ## customization section of script ## for your needs with optional parameters.
If you want to copy the resulting log files onto a central file share, use the switch -CopyLogs
If you want to be informed by email at time of failure, use the switch -SendMail and configure SMTP parameters.
 
Usage:
.\tss_TestShareConn.ps1 [-FileServer EmeaCssDfs -FileShare NetPod -Folder_Perm RFL -DomUserName RegularUser -StartDelaySeconds 1] [-verbose] 

.PARAMETER savePath
 This parameter determines the path for output files; if -savePath is not specified , save logfile into current script path
.PARAMETER FileServer
 by default we are using the $env:COMPUTERNAME where this sctipt runs on, for probing share and folder access
.PARAMETER FileShare
 specify a share name on $FileServer for testing normal user access
.PARAMETER Folder_Perm
 specify a Folder name located in \\$FileServer\$FileShare\$Folder_Perm where $DomUserName is supposed to have sufficient permission
.PARAMETER DomainName
 specify a user account domain name
.PARAMETER DomUserName
 specify a standard domain user name without admin rights
.PARAMETER AdminUserName
 specify a user name with admin rights on the File server. This script will run TSS and same Admin will be creator of Scheduled task
.PARAMETER DomUsrPassword
 specify the password for test user $DomUserName 
.PARAMETER DriveLetter
 specify the drive letter to be connected for this test to map \\$FileServer\$FileShare /user:
.PARAMETER StartDelaySeconds
 start performing user access test x seconds after script invocation, use this switch to delay script execution on systems that take a longer time to start Server service
.PARAMETER RebootDelaySeconds
 if this paramter is not set to value 0 (= no reboot) the restart computer after x seconds at end of this script
.PARAMETER noProgramList
 run script with -noProgramList switch, if you don't wish to list all installed programs on $FileServer
.PARAMETER noDiscard
 run script with -noDiscard, if you want to keep data for a good case too
.PARAMETER SendMail
 run script with -SendMail, if you want to send results per email to user Admin1@contoso.com definded in script customization section
.PARAMETER MailSSL
 use SendMail with switch: -MailSSL, needed i.e. for 'smtp.office365.com'
.PARAMETER MailCreds
 use SendMail with switch: -MailCreds, needed i.e. for 'smtp.office365.com', ask for email creds if no PW is specified
.PARAMETER MailDelivery
 use SendMail with switch: -DeliveryNotificationOption OnSuccess, OnFailure
.PARAMETER Priority
 use SendMail with parameters: -Priority 'Normal' or 'High'
.PARAMETER CopyLogs
 run script with -CopyLogs, if you want to copy individual server log files onto central file share: CentralFSsharePath
.PARAMETER SchTaskCreate
 Use this parameter as the only parameter to Register-ScheduledTask: Create a Task to run this script in TaskScheduler at each server Start, then exit script
.PARAMETER SchTaskRemove
 Use this parameter as the only parameter to Unregister-ScheduledTask: Remove this script from TaskScheduler, then exit script
.PARAMETER CentralFSsharePath
 Central network location \\Server\Share\Logs, where to copy resulting log files
.PARAMETER TssCommand
 TSS Command to run next -- for testing you can use ".\TSS.cmd SMBsrv persistent mini nocab noRecording nowait"
 
.EXAMPLE
 .\tss_TestShareConn.ps1 -SchTaskCreate
  to be used as the only input parameter to Register-ScheduledTask
.EXAMPLE
 .\tss_TestShareConn.ps1 -SchTaskRemove
  to be used as the only input parameter to Unregister-ScheduledTask
.EXAMPLE
 .\tss_TestShareConn.ps1 -FileServer EmeaCssDfs -FileShare NetPod -Folder_Perm RFL DomainName Contoso -DomUserName RegularUser -DomUsrPassword My_Secure!Password -StartDelaySeconds 10
 we connect as Contoso\RegularUser to \\EmeaCssDfs\NetPod and test access for subfolder RFL
.EXAMPLE
.\tss_TestShareConn.ps1 -noProgramList -noDiscard -SendMail -TssCommand ".\TSS.cmd SMBsrv persistent mini nocab noRecording nowait AcceptEula noUpdate" 
i.e. for testing you may want to keep predefined parameters, but skip InstalledPrograms, do not discard previous tss dataset, send email to Admin and use a different TSS command just for testing
#>

[CmdletBinding()]
PARAM (
	[string]$savePath					= "C:\MS_DATA",			# if -savePath is not specified , save logfile into current script path
	[string]$FileServer					= $env:COMPUTERNAME,	# by default we are using the $env:COMPUTERNAME where this sctipt runs on
	[string]$FileShare					= "Test_SMB",				# specify a share name on $FileServer for testing normal user access
	[string]$Folder_Perm				= "_Permission",		# specify a Folder name located in \\$FileServer\$FileShare\$Folder_Perm where $DomUserName has correct Permission
	[string]$AdminUserName				= "Administrator",		# specify an Admin user account with permision to run Schedules Task on file server
	[string]$DomainName					= "Contoso",		# specify a domain name for user accounts
	[string]$DomUserName				= "RegularUser",		# specify a standard domain user name without admin rights
	[string]$DomUsrPassword				= "My_Secure!Password",	# specify the password for test user $DomUserName 
	[string]$DriveLetter				= "T",					# specify the drive letter to be connected for this test to map \\$FileServer\$FileShare
	[int32]$StartDelaySeconds			= 60,					# start performing user access test x Seconds after script invocation
	[int32]$RebootDelaySeconds			= 0,					# any other value than 0 will invoke a computer restart after x seconds as soon as script finished
	[string]$TssCommand					= ".\TSS.cmd SMB persistent LiveKd:both WPR:Network Auth:Basic noRecording nowait AcceptEula nocab noUpdate",	# TSS Command to run next -- for testing use ".\TSS.cmd SMBsrv persistent mini nocab noRecording nowait"
	[string]$CentralFSsharePath 		= "\\server\share\Logs",# Central network location, where to copy resulting log files
	[switch]$noProgramList				= $False,				# run script with -noProgramList, if you don't wish to list all installed programs on $FileServer 
	[switch]$noDiscard					= $False,				# run script with -noDiscard, if you want to keep data for a good case
	[switch]$CopyLogs					= $True,				# set to $True, if you want to copy resulting Logs and data to central FileShare
	[switch]$SchTaskCreate				= $False,				# Create a Task to run this script in TaskScheduler at each server Start
	[switch]$SchTaskRemove				= $False,				# Remove this script from TaskScheduler 
	[switch]$SendMail					= $True,				# send email to Admin1@contoso.com , set switch to $True if you want to email results
	 [switch]$MailSSL					= $False,				# send email using: -MailSSL
	 [switch]$MailDelivery				= $False,				# send email using: -DeliveryNotificationOption OnSuccess, OnFailure
	 [switch]$MailCreds					= $False,				# send email using: -Credential and ask for email creds if no PW is specified
	 [string]$Priority 					= 'High'				# send email using: -Priority 'Normal' or 'High'
	)
	
###### customization section of script #########################################################################
# All optional: # actual setting	 		# Example for your config	| Explanation/sample
# ------------- = ------------------ 		#-------------------------	| ------------------------------
$To_emailUserName = 'Admin1@contoso.com'	# 'Admin1@contoso.com'		| The sender of the email (-From: -To:)
$SmtpServerName = 'outlook.office365.com'	# 'smtp.office365.com'	| The SMTP ServerName to be used for sending email 'mailout.coreandmain.com' ; 'outlook.office365.com' requires -useSsl -Credential (Get-Credential)
$SmtpUserEmail  = 'User@outlook.com'		# email user name on SmtpServer used for Send-MailMessage -Credential
$SmtpEmailPW	= 'my_pass'					# if -MailCreds and no PW is specified, will ask for -Credential (Get-Credential)
$invokeTSS		= $True						# for testing only, when set to $False TSS data collection will ot be invoked
###### end customization section of script #####################################################################
	
#region ::::: Variables ::::
	$ScriptVersion 		= "2021.03.07.0"
	$errorActionPreference = 'Continue'
	$scriptStartTime	= Get-Date # Capture Script start time
	$scriptName			= $($Myinvocation.MyCommand.Name)
	$invocationLine		= $($MyInvocation.Line)
	$ScriptParentPath	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$Drive= $DriveLetter + ":"
	$UserDNSdom 		= $DomainName	#$env:USERDNSDOMAIN
	if ($noProgramList) {[bool]$ListAllInstalledPrograms = 0}
	if ($MailCreds) {
		 if ( $SmtpEmailPW -ne '') {$Credential = (New-Object System.Management.Automation.PSCredential($SmtpUserEmail, (ConvertTo-SecureString $SmtpEmailPW -AsPlainText -Force))) 
		} else { Write-Host -ForegroundColor Yellow "Please enter email creds for $SmtpUserEmail"; $Credential = Get-Credential}
	}
	$Logfile 			= $savePath + "\" + $env:computername + "_" + $UserDNSdom + "_" + $scriptStartTime.ToString('yyyyMMdd_HHmm') + "_ServerReboot.txt"
	$LogDebugfile		= $savePath + "\" + $env:computername + "_" + $scriptStartTime.ToString('yyyyMMdd_HHmm') + "_Debug_ServerReboot.txt"
	$wmiOSVersion 		= gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn 			= [int]$wmiOSVersion.BuildNumber
	$CurrentUsrName			= [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
	#$computername		= $env:COMPUTERNAME
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent()) 
	$isElev = ($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator))
	if (-not $isElev) { Write-Host -ForegroundColor Yellow "It is recommended to start this script with elevated priv - Run as Administrator, so that TSS will run successfully`n
			 === Please respond with 'y' to proceed, or 'n' key to exit.  ===`n" 
		do {
			$UserDone = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
			if ($UserDone.Character -ieq 'n') {exit}
		} until ($UserDone.Character -ieq 'y')
	}
	#Capture computer information
	$windowsversion = [System.Environment]::OSVersion.Version.ToString()
	$PSversion = Get-Host | Select-Object Version 
	#$PSversion = get-PSversion
	$lastBootupTime = Get-CimInstance -ClassName win32_operatingsystem | select csname, lastbootuptime
#endregion ::::: Variables ::::
Write-host ""

#region ::::: Helper Functions ::::
Function LogWrite {
    Param ( [string]$logstring, [switch]$verbose, [switch]$error, [switch]$success, [switch]$timeIt )
	#if ($timeIt) {$TimeNow = (get-date).ToString('hh:mm:ss.fff'); [string]$LogLine = -join($TimeNow, " ", $logstring); Add-Content $Logfile -value $LogLine}
    if ($verbose) { #write only to Logfile
		Add-Content $Logfile -value $logstring
    } elseif ($error) {
		Add-Content $Logfile -value $logstring -PassThru | Write-Host -ForegroundColor red
	} elseif ($success) {
		Add-Content $Logfile -value $logstring -PassThru | Write-Host -ForegroundColor green
    } else {
        Add-content $Logfile -value $logstring -PassThru
    }
}

Function Zip-Files {
	# Function Zip-Files( $zipfilename, $sourcedir )
	Param (
		[Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$false)]
		[string] $zipfilename,
		[Parameter(Position=1, Mandatory=$true, ValueFromPipeline=$false)]
		[string] $sourcedir,
		[Parameter(Position=2, Mandatory=$false, ValueFromPipeline=$false)]
		[bool] $overwrite
	)
	if ($PSVersionTable.PSVersion.Major -le 2) 
		{ Write-Output "Compression not supported for this PS version: $($PSVersionTable.PSVersion.Major)"}
	else {
		Add-Type -Assembly System.IO.Compression.FileSystem
		$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
		if ($overwrite -eq $true ) { if (Test-Path $zipfilename) { Remove-Item $zipfilename } }
		[System.IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $zipfilename, $compressionLevel, $false)
	}
}

Function WriteConfigToLog {
	LogWrite "ScriptInvocation   : $invocationLine"
	LogWrite "Started on         : $FileServer  - by User: $CurrentUsrName"
	LogWrite "Date of test start : $($scriptStartTime.ToString('F'))"
	LogWrite " Start time (UTC)  : $((Get-Date).ToUniversalTime())"
	LogWrite " Start time (Local): $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})"
	LogWrite "Windows Version    : $windowsversion"
	LogWrite "User DNS Domain    : $UserDNSdom "
	LogWrite " FileServer        : $FileServer  - by default we are using this FileServer where this script $scriptName runs on" -verbose
	LogWrite " FileShare         : $FileShare  - a share name on $FileServer for testing normal user access" -verbose
	LogWrite " Drive             : '$Drive'  - the drive letter to be connected for this test to map \\$FileServer\$FileShare"  -verbose
	LogWrite " Folder_Perm       : '$Folder_Perm'  - standard domain user has sufficient Perm for listing this sub folder" -verbose
	#LogWrite " Folder_NoPerm     : '$Folder_NoPerm'  - standard domain user has no Perm for this sub folder" -verbose
	LogWrite " DomUserName       : $DomUserName  - a standard domain user name without admin rights"  -verbose
	LogWrite " DomUsrPassword    : ******** "  -verbose
	LogWrite " CurrentUsrName    : $CurrentUsrName  - Username, which started this script"  -verbose
	LogWrite " DomainName        : $DomainName  - the users Domain name"   -verbose
	LogWrite " To_emailUserName  : $To_emailUserName  - email Username, which will receive the email message"  -verbose
	LogWrite " StartDelaySeconds : $StartDelaySeconds  - time gap in seconds until starting FileServer connectivity test" 	
	LogWrite " RebootDelaySeconds: $RebootDelaySeconds  - time delay for next aut reboot. Any other value than 0 will invoke a computer restart after x seconds as soon as script finished"
	LogWrite " noProgramList     : $noProgramList "  -verbose
	LogWrite " noDiscard         : $noDiscard "   -verbose
	LogWrite " Logfile           : $Logfile "
	LogWrite " LogDebugfile      : $LogDebugfile "  -verbose
	LogWrite " CopyLogs          : $CopyLogs "  -verbose
	LogWrite " SendMail          : $SendMail "  -verbose
	LogWrite "  SmtpServerName   : $SmtpServerName  - SMTP ServerName to be used for sending email"  -verbose
	LogWrite "  SmtpUserEmail    : $SmtpUserEmail  - email user name for Send-MailMessage -Credential"  -verbose
	LogWrite "  UseSSL           : $MailSSL "  -verbose
	LogWrite "  MailDelivery     : $MailDelivery "  -verbose
	LogWrite "  MailCreds        : $MailCreds "  -verbose 
	LogWrite " CentralFSsharePath: $CentralFSsharePath "  -verbose
	LogWrite "TSScommand         : $TSScommand " 
	LogWrite "ScriptParentPath   : $ScriptParentPath" -verbose
	LogWrite " Powershell version: $PSversion" -verbose
	#LogWrite ($PSversion | Out-String)
	LogWrite " Last Boot Time    : $lastBootupTime" -verbose
	#LogWrite ($lastBootupTime | Out-String)
	LogWrite "$((get-date).ToString('hh:mm:ss.fff')) === Status of Server service ===============================" 
	 $ServerService = Get-Service "Server" | Select-Object status, name, displayname, starttype | Format-Table
	LogWrite ($ServerService | Out-String)
 }
 
Function CollectInstalledPrograms {
	### Add a list of installed programs
	if ($ListAllInstalledPrograms -ne 0) {
		 # This adds an additional 30 seconds to the script
		 LogWrite " "
		 Write-Verbose "ListAllInstalledPrograms: $ListAllInstalledPrograms"
		 # Loop through a message until WMI call started at the beginning finishes
		 LogWrite "$((get-date).ToString('hh:mm:ss.fff')) === Installed Programs ==================================" -verbose
		 LogWrite "Collecting all installed programs" | Write-Host -NoNewLine
		 While ($ListInstalledPrograms.JobStateInfo.State -ne "Completed") {
			Write-Host '.' -nonewline
			Start-Sleep -milliseconds 1000
		 }
		 LogWrite (Receive-Job -job $ListInstalledPrograms | Out-String -Width 1024) -verbose
		 Write-verbose "ListAllInstalledPrograms_Done " 
		 LogWrite "`n=====================================================================" -verbose
	}
}

Function SendMail {
	Param ( [string]$subject ='TSS stopped on server $FileServer',
			[switch]$verbose, [switch]$error)
	if ( ($SendMail -ne $False) -and ($SmtpServerName -ne '')) {		
		## Define the Send-MailMessage parameters
		$mailParams = @{
			SmtpServer                 = $SmtpServerName
			From                       = $To_emailUserName
			To                         = $To_emailUserName
			Subject                    = $subject	#"SMTP Client Submission - $(Get-Date -Format g)"
			Body                       = 'TSS Alert: Find the report attached. Good case data were discarded'
			Attachments					= $Logfile,$LogDebugfile
		}
		### Send email trying 2 attemts, waiting 5 sec between failure
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) === Trying to Send alert per Email to $To_emailUserName via SmtpServer $SmtpServerName====" 
		if ($MailSSL) 		{$mailParams['UseSSL']=$true ; $mailParams['Port']='587'}
		if ($MailDelivery) 	{$mailParams['DeliveryNotificationOption']='OnFailure', 'OnSuccess' ; $mailParams['Priority']=$Priority}
		if ($MailCreds) 	{$mailParams['Credential']=$Credential}
		$mailParams
		$n=1
        Do
        {
            LogWrite "Attempt $n - Sending email to $To_emailUserName"           
            $ErrorMessage = $null
			## Send the message
			Send-MailMessage  -ErrorAction SilentlyContinue -ErrorVariable SendError @mailParams
			$ErrorMessage = $SendError.exception.message
			Write-Host "$ErrorMessage"
            If ($ErrorMessage)
            {
                LogWrite "Failure $n - $ErrorMessage"
                Start-Sleep -Seconds 5
            }
            $n++
        } 
        Until ( $SendError.exception.message -eq $null -or $n -eq 3 )
        If($SendError.exception.message -eq $null)
        { LogWrite "$((get-date).ToString('hh:mm:ss.fff')) SUCCESS: Email has been sent to $To_emailUserName via SmtpServer $SmtpServerName" -success
		} Else { LogWrite "$((get-date).ToString('hh:mm:ss.fff')) FAILED: sending email to $To_emailUserName via SmtpServer $SmtpServerName" -error }
	}
}

Function TestUserAccess {
	LogWrite "$((get-date).ToString('hh:mm:ss.fff')) ==== UserAccess tests ===============================================" 
	LogWrite "$((get-date).ToString('hh:mm:ss.fff')) .. testing access to share: NET USE $Drive \\$FileServer\$FileShare /User:$UserDNSdom\$DomUserName *****" 
	$TryConn = ( NET USE $Drive \\$FileServer\$FileShare /User:$UserDNSdom\$DomUserName $DomUsrPassword ) 2>> $LogDebugfile
	LogWrite "[TryConn]: $TryConn" -verbose
	if ($TryConn) {
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) SUCCESS: Connected share: $Drive \\$FileServer\$FileShare" -success 
		$PathPermcheck = "$Drive\$Folder_Perm"
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) ... testing access to subfolder: $PathPermcheck" 
		if ((Test-Path $PathPermcheck) -eq $true)
		{
			Set-Location $PathPermcheck #-ErrorAction SilentlyContinue
			Get-ChildItem $PathPermcheck 2>> $LogDebugfile #-ErrorAction SilentlyContinue
			if ($Error[0].Exception -is [System.UnauthorizedAccessException])
			{	# fail case
				$Msg = "[$invocationLine] FAILED: no access to $PathPermcheck as user $UserDNSdom\$DomUserName on $FileServer"
				LogWrite "Exception -is [System.UnauthorizedAccessException]" -verbose
				LogWrite $Msg -error 
				LogWrite "Exception Message:`n $error[0]" -verbose
				$Discard = ""
				$Good_Fail = "Fail access"
				LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [$Good_Fail] ... trying to send email"
				SendMail -Subject $Msg
				LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [$Good_Fail] ... passed 'send email'" -verbose
				Write-Host "[$Good_Fail] unable to access $PathPermcheck"
			} else { #good case
				LogWrite " -> $PathPermcheck folder is accessible" -verbose
				$TestResultConn = (Get-ChildItem $PathPermcheck ) 2>> $LogDebugfile
				 if ($TestResultConn.count -eq 0) {LogWrite " -> Access is successfull, but folder does not contain any data"  -verbose}
				LogWrite "$((get-date).ToString('hh:mm:ss.fff')) SUCCESS: Verified READ access to $PathPermcheck for user $UserDNSdom\$DomUserName" -success 
				if ($noDiscard) {$Discard = ""} else {$Discard = "Discard"}
				$Good_Fail = "Good access"
			}
		}
	} else {
		$Good_Fail = "Fail connect"
		$Msg = "[$invocationLine] failed to connect \\$FileServer\$FileShare as user $UserDNSdom\$DomUserName - Please verify"
		LogWrite "Exception Message:`n $error[0]"
		LogWrite $Msg -error 
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [failed to connect Share] ... trying to send email"
		SendMail -Subject $Msg
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [failed to connect Share] ... passed 'send email'"  -verbose
	}
	Set-Location $ScriptParentPath 
	LogWrite " Current dir: $(pwd)" -verbose
	LogWrite "`n$((get-date).ToString('hh:mm:ss.fff')) [$Good_Fail] Now stopping persistent TSS data collection: $ScriptParentPath\TSS OFF $Discard - Please be patient ~10 min until TSS OFF has finished..."
	LogWrite " or lookup C:\MS_DATA\tss_Date-Time\$($env:computername)_Date-Time__LogFile_off.txt in TSS results folder for TSS OFF errors`n"
	$TssStartTime = Get-Date
	Write-Host -ForegroundColor yellow "TssStartTime: $TssStartTime - Please be patient"
if ($invokeTSS) {	( & $ScriptParentPath\tss.cmd OFF $Discard ) 2>> $LogDebugfile }
	$TssEndTime = Get-Date
	Write-Host -ForegroundColor yellow "TssEndTime: $TssEndTime"
	$Tss_duration = (New-TimeSpan -Start $TssStartTime -End $TssEndTime).seconds
	LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [Duration: $Tss_duration seconds] ... TSS OFF $Discard finished `n"
	if ($TryConn) {
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [$Good_Fail] .. disconnecting user drive: NET USE $Drive /DEL"
		$TestResultDisConn = ( NET USE $Drive /DEL ) 2>> $LogDebugfile
		if ($TestResultDisConn) {LogWrite "$((get-date).ToString('hh:mm:ss.fff')) SUCCESS: Disconnected drive $Drive" -success } else {LogWrite "$((get-date).ToString('hh:mm:ss.fff')) FAILED: Disconnect of drive $Drive" -error }
	}
}

Function SchTaskCreate {
	Param ( [string]$SchTaskName, [int32]$StartupDelay=59)
	[string]$TR = -join($ScriptParentPath, "\", $SchTaskName, ".ps1")
	if ($bn -lt 9200) { #for downlevel OS 2008/R2
		LogWrite "[$bn] ..run command: SchTasks.exe /Create /RU $AdminUserName /SC ONSTART /TN $SchTaskName /TR $TR /DELAY 0001:30 /F" 
		SchTasks.exe /Create /RU $AdminUserName /SC ONSTART /TN $SchTaskName /TR "PowerShell.exe -ExecutionPolicy Bypass -File $TR" /DELAY 0001:30 /F
	} else { # for Win8+ 9200
		LogWrite "[$bn] .. running Register-ScheduledTask $SchTaskName" 
		$action  = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -file $($TR)"
		$trigger = New-ScheduledTaskTrigger -AtStart
		#$taskPrincipal = New-ScheduledTaskPrincipal -UserId "$DomainName\$AdminUserName" -RunLevel Highest
		#$taskSettings = New-ScheduledTaskSettingsSet -Compatibility Win8
		Register-ScheduledTask -User "$DomainName\$AdminUserName" -Action $action -Trigger $trigger -TaskName $SchTaskName -Description TSS_Stop_Start_at_each_reboot #-Principal $taskPrincipal #-Settings $taskSettings
		#Set-ScheduledTask -TaskName $SchTaskName -User $taskPrincipal.UserID -Password 'PASSWORD'
		#Set-ScheduledTask -TaskName $SchTaskName -Settings $taskSettings -Principal $taskPrincipal
		#Start-ScheduledTask -TaskName $SchTaskName -ErrorAction SilentlyContinue
	}
}
Function SchTaskRemove {
	Param ( [string]$SchTaskName)
	#Remove_SchTask [TaskName]
	if ($bn -lt 9200) { #for downlevel OS
		LogWrite "[$bn] .. running: SchTasks.exe /delete /TN $SchTaskName /F" 
		SchTasks.exe /delete /TN $SchTaskName /F
	} else { # for Win8+ 9200
		LogWrite "[$bn] .. running Stop-ScheduledTask and Unregister-ScheduledTask $SchTaskName" 
		if (Get-ScheduledTask -TaskName $SchTaskName -EA SilentlyContinue ) {
			Stop-ScheduledTask -TaskName $SchTaskName
			Unregister-ScheduledTask -Confirm:$false -TaskName $SchTaskName
		} else {LogWrite "[$bn] .. Task $SchTaskName does not exist" -error}
	}
}
Function CopyLogs {
	if (Test-Path $CentralFSsharePath) {
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) .. copy or move resulting logs to $CentralFSsharePath" 
		if (Test-Path "$Logfile") { Copy-Item $Logfile -Destination $CentralFSsharePath -Force -EA SilentlyContinue}
		if (Test-Path "$LogDebugfile") { Copy-Item $LogDebugfile -Destination $CentralFSsharePath -Force -EA SilentlyContinue}
	}
}
#endregion ::::: Helper Functions ::::

#region ::::: MAIN ############################################################################################
	# check for SchTaskCreate or SchTaskRemove
	if ($SchTaskCreate -or $SchTaskRemove) {
		if ($SchTaskCreate) { SchTaskCreate tss_TestShareConn}
		if ($SchTaskRemove) { SchTaskRemove tss_TestShareConn}
	}
	else {
		# Main Test routine
		# Note: Trying to Start this Win32_Product task early while working on other tasks
		$ListInstalledPrograms = Start-Job -scriptblock {Get-WmiObject -Class Win32_Product | sort-object name | Format-Table Name, Version, InstallDate}

		WriteConfigToLog
		
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) Will delay the UserAccess tests for $StartDelaySeconds seconds ..." 
		Start-Sleep -s $StartDelaySeconds
		# running actial user access test
		TestUserAccess
		
		Set-Location $ScriptParentPath #-PassThru
		LogWrite " Current dir: $(pwd)" -verbose
		LogWrite "`n$((get-date).ToString('hh:mm:ss.fff')) .. Now proceeding with consequtive next TSS command:"
		LogWrite "Please be patient ~10 min until new  $TssCommand  has finished ..."
		LogWrite " -> lookup C:\MS_DATA\tss_Date-Time\$($env:computername)_Date-Time__LogFile_on.txt for TSS progress or startup errors`n"
		$TssReStartTime = Get-Date
		Write-Host -ForegroundColor yellow "TssReStartTime: $TssReStartTime - Please be patient"
		if ($invokeTSS) { (Invoke-Expression $TssCommand)  2>> $LogDebugfile }
		$TssReStartFinishedTime = Get-Date
		Write-Host -ForegroundColor yellow "TssReStartFinishedTime: $TssReStartFinishedTime"
		$Tss_duration = (New-TimeSpan -Start $TssReStartTime -End $TssReStartFinishedTime).seconds
		LogWrite "$((get-date).ToString('hh:mm:ss.fff')) [Duration: $Tss_duration seconds] .. passed Invoke-Expression $TssCommand "
		
		CollectInstalledPrograms
		if ($CopyLogs) { CopyLogs }
		
		if ($RebootDelaySeconds -ne 0) {
			LogWrite "`n$((get-date).ToString('hh:mm:ss.fff')) .. A computer restart will be forced in $RebootDelaySeconds seconds"
			#Start-Sleep -s $RebootDelaySeconds
			shutdown.exe /r /f /t $RebootDelaySeconds
		} else { LogWrite "`n..script will not schedule automatic reboot"}
	}
	
#endregion ::::: MAIN 

$scriptEndTime = Get-Date
$script_duration = (New-TimeSpan -Start $scriptStartTime -End $scriptEndTime).seconds
LogWrite "`n$((get-date).ToString('hh:mm:ss.fff')) End script $scriptName v$ScriptVersion Execution duration: $script_duration seconds"