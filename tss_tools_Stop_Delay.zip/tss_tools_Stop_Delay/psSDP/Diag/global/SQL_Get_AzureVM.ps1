﻿# SQL_Get_AzureVM.ps1 
# Version 1.0
# Date: 2021-04-06
# Author: WalterE@Microsoft.com
#
# Description: Collect SQL Azure VM Information

$Error.Clear()           
trap 
{
	"[SQL_Get_AzureVM] : Trapped error ..." | WriteTo-Stdout
	Show-ErrorDetails $error[0]
}


if($debug -eq $true){[void]$shell.popup("Run SQL_Get_AzureVM.ps1")}
Import-LocalizedData -BindingVariable AzureVMInformation -FileName SQL_Get_AzureVM -UICulture en-us
	
Write-DiagProgress -Activity $AzureVMInformation.ID_SQL_Setup_Collect_AzureVM -Status $AzureVMInformation.ID_SQL_Setup_Collect_AzureVM_Description

$OutputFile = $ComputerName + "_SQL_AzureVM_Information.txt"
$FileDescription = "SQL AzureVM Information Output"
$sectionDescription = "SQL AzureVM Information"

#RunCmD -commandToRun $CommandLineToExecute -sectionDescription $AzureVMInformation.ID_SQL_Setup_AzureVM -filesToCollect $OutputFile -fileDescription $AzureVMInformation.ID_SQL_Setup_Collect_AzureVM

Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Proxy $Null -Uri "http://169.254.169.254/metadata/instance?api-version=2020-09-01" -ErrorAction SilentlyContinue | ConvertTo-Json -Depth 64 | OutFile -FilePath $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription $FileDescription -sectionDescription $SectionDescription -renameOutput $false