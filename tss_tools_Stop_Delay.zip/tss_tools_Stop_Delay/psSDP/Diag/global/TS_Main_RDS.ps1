# Load Common Library
$debug = $false

. ./utils_cts.ps1

$FirstTimeExecution = FirstTimeExecution
if($debug -eq $true){[void]$shell.popup("FirstTimeExecution: $FirstTimeExecution")}

if ($FirstTimeExecution) 
{
	#Import-LocalizedData -BindingVariable RDSSDPStrings
	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_RDS.ps1
			
	EndDataCollection
} 
else
{
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}


