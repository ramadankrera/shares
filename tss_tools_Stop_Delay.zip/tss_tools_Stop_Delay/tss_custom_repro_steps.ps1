# File: tss_custom_repro_steps.ps1 [-Folderpath] [-Loop_Cnt]
# Purpose: run extra repro steps
#		   you can use this script i.e. in combination with Stop:ps1:Reg:300 ; all the steps will be performed repeatedly in a loop within script tss_stop_condition_script.ps1 until the Reg stop condition is met

param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),	# where to store Logs
	[Int32]$Loop_Cnt = 0														# Repro Loop counter
)

$VerDate = "2021.02.18.1"
$ReproLog = $Folderpath + "\" + $Env:Computername + "__8021xlog.txt"	# LogFile Path
#$ScriptParentPath = (Get-Location).path
$ScriptParentPath = Split-Path $MyInvocation.MyCommand.Path -Parent
# Write-Host "...now running Repro Steps from script $ScriptParentPath\tss_custom_repro_steps.ps1 "
"`n [$Loop_Cnt] __________________" | Out-File $ReproLog -Append
"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $ReproLog -Append


##### customize section - enter your customized commands below #####
# Note: this scripts expects that the two files "Lan.xml" and "userinfo.xml" are found in current tss_tools folder

"Lan.xml","UserInfo.xml"| ForEach-Object {if (-not (Test-Path "$ScriptParentPath\$_")) {Write-Host " [Warning] File $ScriptParentPath\$_ is missing"} }

netsh lan add profile filename="$ScriptParentPath\Lan.xml" interface="E*" >> $ReproLog 
Start-Sleep 5
netsh lan set eapuserdata filename="$ScriptParentPath\UserInfo.xml" allusers=yes interface="E*" >> $ReproLog

## uncomment next lines if we need to reconnect LAN interface
# Start-Sleep 10
# netsh lan reconnect interface="E*" >> $ReproLog

## uncomment next lines if we need to stop and restart the service
# SC.exe stop dot3svc
# Start-Sleep 5
# SC.exe start dot3svc
# Start-Sleep 1

## uncomment next line if we should query service status for each iteration
# SC.exe queryEx dot3svc  >> $ReproLog