<# Name: tss_EvtMonPS.ps1 [-EventIDs -EventlogName -CheckIntInSec -WaitTimeInSec -EventData -EvtDataPartial -EvtDataOperator]
	
if you invoke from CMD:
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {$EventID=30800;$NrOfMilliSec=60000;$EventlogName="Microsoft-Windows-SmbClient/Operational"; Get-WinEvent -LogName $EventlogName -FilterXPath "*[System[EventID=$EventID and TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]]" -MaxEvents 5 -ErrorAction SilentlyContinue}}"
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {Get-WinEvent -LogName "Microsoft-Windows-SmbClient/Operational"  -FilterXPath "*[System[EventID=30800]]" -MaxEvents 3 -ErrorAction SilentlyContinue }}"

	#Eventlogs location on disk: "C:\Windows\System32\winevt\Logs\Microsoft-Windows-SmbClient%4Operational.evtx"
Example to delete Source
 Get-WmiObject win32_nteventlogfile -Filter "logfilename='Microsoft-Windows-SmbClient/Operational'" | foreach {$_.sources}
 Remove-Eventlog -Source "TSS"

For Testing:
 you can watch for 40961/40962 in "Microsoft-Windows-PowerShell/Operational", which is logged when starting a  new PoSh window
#>

<#
.SYNOPSIS
Purpose: Monitor Eventlogs for specific event and stop script; in combi with TSS: stop the script based on EventIDs in a non classic Eventlog
	The stop trigger condition is true if the EventID is found in specified Eventlog up to CheckIntInSec back in time, the control is given back to calling script.
	From CMD script you can invoke this PowerShell script by: Powershell -noprofile -file "tss_EvtMon.ps1" -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0
	Multiple EventIDs are separated by '/', for example -EventID 40961/40962
	Multiple EventData strings are separated by '/', for example -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 
SYNTAX: .\tss_EvtMon.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 'find-my-string'


.DESCRIPTION
The script will stop, once the specific details EventID(s) and Eventdata string(s) are all met.
You need to run the script in Admin PowerShell window, if you want to monitor 'Security' Event Log
You can append the -verbose parameter to see more details.
When entering -EventData string, please enter the complete string as seen in Event 'XML View', for example 'C:\Windows\System32\calc.exe'
 as seen in 'XML View' <Data Name="NewProcessName">C:\Windows\System32\calc.exe</Data> 
In additin to any specific EventID, the script will also listen on EventID 999 in Application eventlog, and stop when it sees 999 sent by a remote system as a stop trigger.

.PARAMETER EventIDs
	The Event ID to watch for, separate multiple IDs with '/', ex: 30800/30809
.PARAMETER CheckIntInSec
	Specify how often (time-interval in seconds) to search for given EventID(s)
.PARAMETER EventlogName
	Specify name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" or "Microsoft-Windows-SmbClient/Operational"
.PARAMETER WaitTimeInSec
	Force a wait time in seconds after an event is found,  this will instruct tss to stop x seconds later.
.PARAMETER EventData
	Specify a complete string that is seen in Eventlog XML view <Data>"your complete string"</Data>
.PARAMETER EvtDataPartial
	Specify a unique keyword that is part of the complete message, to allow search for partial event data message
	This does not require a full string between <Data> .. </Data>, partial match is ok
.PARAMETER EvtDataOperator
	combine multiple EventData search terms by AND or OR operator (default = OR)
	
.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 4688/4689 -EventlogName "Security" -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe -verbose
 
This will monitor for multiple EventIDs  4688 and 4689, checking if either string 'C:\Windows\System32\calc.exe' or 'C:\Windows\System32\cmd.exe' exist in given EventID(s) 

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 40961/40962 -EventlogName "Microsoft-Windows-PowerShell/Operational" -EventData 0
 
 This will monitor for multiple EventIDs 40961 and 40962 in Microsoft-Windows-PowerShell/Operational, will be triggered as soon as a new PowerShell window opens

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 4624 -EventlogName "Security" -EventData "Contoso.com/User1" -EvtDataPartial -EvtDataOperator "AND"
 
 This will monitor for EventID 4624 in Security eventlog, will be triggered as soon as a Logon attempt from "User1" in domain "Contoso.com" is logged, AND means both criteria must match; omitting -EvtDataOperator or choosing "OR" will fire if one criteria is found in EventID 4624
 
 
 .EXAMPLE

  [Info] for testing it is sufficient to specify an existing "Source", i.e.
  Write-EventLog -LogName "Application" -Source "Outlook" -EventID 59 -EntryType Information -Message "Test this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
  Note, you can also use the script tss_EventCreate.ps1 to fire such event.

.LINK
waltere@microsoft.com;Sergey.Akinshin@microsoft.com
#>

Param(
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose the EventID, or multiple separated by slash / ')]
	[string[]]$EventIDs 		# separate multiple IDs with '/', ex: 30800/30809
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Choose name of EventLog-File' )]
	[string]$EventlogName 		# name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" #"Microsoft-Windows-SmbClient/Operational"
	,
	[Parameter(Mandatory=$False,Position=3,HelpMessage='Choose the amount of time to search back in seconds ')]
	[Int32]$CheckIntInSec = 2	# specify time-interval in seconds to search back, # how often in seconds should the evenlog file be scanned?
	,
	[Parameter(Mandatory=$False,Position=4,HelpMessage='Choose Stop WaitTime in Sec')]
	[Int32]$WaitTimeInSec = 0	# this specifies the forced wait time after an event is detected
	,
	[Parameter(Mandatory=$False,Position=5,HelpMessage='optional: complete string in any EventData, or multiple separated by slash / ')]
	[string[]]$EventData = '0'	#'3221226599' # = STATUS_FILE_NOT_AVAILABLE / '3221225996' = STATUS_CONNECTION_DISCONNECTED / '0' = STATUS_SUCCESS
	,
	[Parameter(Mandatory=$False,Position=6,HelpMessage='Search for keywords in event Message')]
	[Switch]$EvtDataPartial		# allow search for partial event data message
	,
	[Parameter(Mandatory=$False,Position=7,HelpMessage='choose operator for EventData: AND OR')]
	[string]$EvtDataOperator="OR"	# AND will fire only if both conditions are true
)

#region: customization section of script, logging configuration ----------------------#
$ScriptVer			= "1.09"	# Date: 2020-09-16

[Int32]$cntr		= 0			# counter
[Int32]$MaxEvents	= 1			# we are only interested in a single recent occurence of EventID in Eventlog
$Trigger			= $False	# initialize; While Loop will exit when Trigger=$True
[Int32]$NrOfMilliSec = 1000 * ($CheckIntInSec +5)	#amount of time in MilliSec to search back
$NrOfSecBack		= 10		# Search EvtLog back for x seconds
#endregion: customization section of script, logging configuration -------------------#


#region: MAIN ------------------------------------------------------------------------#

[string[]]$Event_ID_list=$EventIDs.split("/")
[string[]]$Event_ID_list_comma=$EventIDs.replace("/",",")
Write-verbose "--EventIDs: $Event_ID_list"
[array]$xpaths= @()
$EvtDataStrings=$EventData.split("/")
[string]$EvtDataStrings_Or	= $EventData.replace("/","|")	# default OR operator in partial EventData search
[string[]]$EvtDataStrings_And	= $EventData.Split("/") 	# implement AND operator for multple partial EventData words

Write-verbose "--EvtDataStrings:     $EvtDataStrings"
Write-verbose "--EvtDataStrings_Or:  $EvtDataStrings_Or"
Write-verbose "--EvtDataStrings_And: count: $($EvtDataStrings_And.count) Search for: [1] $($EvtDataStrings_And[0]) AND [2] $($EvtDataStrings_And[1])"

foreach ($EventID in $Event_ID_list){
	if ($EvtDataPartial) {	# This does not require a full string between <data> .. </data>, partial match is ok
			$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
	$xpaths += $xpath
	Write-host "---- EventID: $EventID - Xpath: `n$xpath"
	} 
	else {				# full match of 'EvtDataString'
		foreach ($EvtDataString in $EvtDataStrings)
		{
			if ($EventData -ne '0') {
				$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
[EventData[Data='$EvtDataString']]
"@
			} else {
			$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
			}
			
		$xpaths += $xpath
		Write-host "---- EventID: $EventID - Xpath: `n$xpath"	
		}
	}	
}

# watch in addition for App Event ID 999
$xpath999 = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=999]]
"@

if ($EvtDataPartial) { Write-host " - EvtDataPartial: allow search for partial string(s) in event message, operator $EvtDataOperator : '$EvtDataStrings'" }
Write-host -ForegroundColor Green " Monitoring $EventlogName Log for EventID(s): '$Event_ID_list' EventData operator: $EvtDataOperator '$EvtDataStrings' - CheckInterval $CheckIntInSec sec"
 $TimeStampStart= Get-Date
 # Run While loop until Event is recorded 
while (-not $Trigger) {
	Start-Sleep $CheckIntInSec;
	$TimeStartCompare  = (Get-Date).AddSeconds(-$NrOfSecBack)	# look back 10 sec in EvtLog
	$cntr++ ;  write-verbose " `n`n  Loop# $cntr; $(Get-Date -Format 'yyMMdd-hhmmss') - monitoring EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings' Operator: $EvtDataOperator NrOfSecBack: $NrOfSecBack"
	##Write-verbose "--xPath: $xpath"
	
	if (($EvtDataPartial) -and ( -not($EvtDataOperator -ieq "OR"))) {	# Partial Event message and Operator = "AND"
		#Test 5140 = 'File Share': Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = "Security"; StartTime = $TimeStartCompare; ID = 4674 } |Where-Object -Property Message -match "EUROP" |Where-Object -Property Message -match "walt" | select Id,TimeCreated,Message |format-list
		if ($EvtDataStrings_And.count -eq 1) {
			foreach($Event_ID in $Event_ID_list) {
				write-verbose "Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName; StartTime = $TimeStartCompare; ID = $Event_ID }  |Where-Object -Property Message -match $($EvtDataStrings_And[0]) `n"
				$EvtEntry = Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName ; StartTime = $TimeStartCompare; ID = $Event_ID } -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_And[0] | select Id,TimeCreated,Message 
				if ($EvtEntry) { break}
			}
		}
		elseif ($EvtDataStrings_And.count -eq 2) {
			foreach($Event_ID in $Event_ID_list) {
				write-verbose "Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName; StartTime = $TimeStartCompare; ID = $Event_ID }  |Where-Object -Property Message -match ($($EvtDataStrings_And[0]) -AND $($EvtDataStrings_And[1])) `n"
				## works for single EventID, but not @($Event_ID_list_comma) = (input "4674/4957")
				$EvtEntry = Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName ; StartTime = $TimeStartCompare; ID = $Event_ID } -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_And[0] |Where-Object -Property Message -match $EvtDataStrings_And[1]  | select Id,TimeCreated,Message 
				if ($EvtEntry) { break}
			}
		}
	}
	else {	# # Partial Event message and Operator = "OR", or no Partial
		foreach ($xpath in $xpaths) 
		{ Write-debug "-- xpathCount: $($xpaths.count) -- xPath: $xpath"
			if ($EvtDataPartial) { # search for partial string in EventData
				Write-debug "Partial: $EvtDataPartial"	
				if ($EvtDataOperator -ieq "OR") { 	# Operator "OR", default
					write-verbose "Get-WinEvent -LogName $EventlogName -FilterXPath $xpath  |Where-Object -Property Message -match $EvtDataStrings_Or"
					$EvtEntry = Get-WinEvent -LogName $EventlogName -MaxEvents $MaxEvents -FilterXPath $xpath -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_Or |select Message,Id,TimeCreated
					if ($EvtEntry) {$EvtEntry; break}
				} 
				else { 														
				}
			} 
			else { 			# search for full string in EventData
				write-verbose "Get-WinEvent -MaxEvents $MaxEvents -LogName $EventlogName -FilterXPath $xpath "
				$EvtEntry = Get-WinEvent -MaxEvents $MaxEvents -LogName $EventlogName -FilterXPath $xpath -ErrorAction SilentlyContinue |select Message,Id,TimeCreated
				if ($EvtEntry) {$EvtEntry; break}
			}
		}
	}
	# in addition check for Event ID 999 in Application EvtLog
	$EvtEntry999 = ( Get-WinEvent -MaxEvents $MaxEvents -LogName Application -FilterXPath $xpath999 -ErrorAction SilentlyContinue |select Message,Id,TimeCreated )
	if ($EvtEntry999) {$EvtEntry = $EvtEntry999}

	$Trigger = $EvtEntry
	if ($Trigger) {
		$TimeStampCurrent=Get-Date; $Dur=($TimeStampCurrent - $TimeStampStart)
		if ($EvtEntry ) 	{ $EvtEntry |format-list; Write-host -ForegroundColor Yellow " EventID '$($EvtEntry.Id)' - EventData '$EvtDataStrings' found at $($EvtEntry.TimeCreated) - after $($Dur.Days) D $($Dur.Hours) h $($Dur.Minutes) m $($Dur.Seconds) sec / $Dur"}
		Start-Sleep $WaitTimeInSec
		break
	}
}
#endregion: MAIN ---------------------------------------------------------------------#

<# allow partial EventData search? https://www.reddit.com/r/PowerShell/comments/gksxp3/how_to_generate_a_here_string_dynamically/

Test:
$xpath = @"
 *[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
 [EventID=$EventIDs]]
 [UserData[EventData[ClientAddressLength='$EvtDataStrings']]]
"@
[EventData[Data='$EvtDataStrings']]

#EvtDataStrings : 3221226599 # for decimal -1073740697 / hex 0xc0000467 #  STATUS_FILE_NOT_AVAILABLE # The file is temporarily unavailable.
#EvtDataStrings : 3221225996 # for decimal -1073741300 / hex 0xc000020c #  STATUS_CONNECTION_DISCONNECTED
#EvtDataStrings : 3221225653 # STATUS_IO_TIMEOUT # The specified I/O operation on %hs was not completed before the time-out period expired.

# Test: .\tss_EvtMonPS.ps1 -EventID 1006 -EventlogName  'Microsoft-Windows-SMBServer/Security' -EvtDataStrings 128
$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= 1000]]
[EventID=999]]
"@

https://evotec.xyz/powershell-everything-you-wanted-to-know-about-event-logs/
Test: .\tss_EvtMonPS.ps1 -EventID "4674/5140" -EventlogName "Security" -CheckIntInSec 2 -WaitTimeInSec 0 -EventData "waltere/EUROPE" -EvtDataPartial -EvtDataOperator "AND" -verbose	#_# 5140 = 'File Share' / 4674 = 'Sensitive Privilege Use'

#>