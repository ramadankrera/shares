﻿#************************************************
# DC_DPMVerboseTracing.ps1
# Version 1.0.1
# Date: 12/3/2012
# Author: v-maam
# Description:  [Idea ID 6196] [System Center Data Protection Manager] SDP Request - Verbose logging option (tracing) for DPM
# Rule number:  6196
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=6196
#************************************************

$StartTime  = [DateTime]::Now

Import-LocalizedData -BindingVariable ScriptStrings

$Script:DPMRegisoryKeyPath = "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager"
$Script:DPMFolderDir = GetDPMInstallFolder  # GetDPMInstallFolder function from Functions.ps1
 trap [Exception] 
 {
  WriteTo-ErrorDebugReport -ErrorRecord $_ 
  $Error.Clear()
  continue
 }

Function Press_s_key
		Write-Host "`n$(Get-Date -Format "HH:mm:ss") === Press the 's' key to stop verbose tracing. ===`n" -ForegroundColor Green
		do {
			$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
		} until ($x.Character -ieq 's')
}
####################################################################################
# Check to be sure the DPM 2010 or 2012 installed on the DPM server
####################################################################################
#Function CheckTheAvailableDPMVersion
#{
#	if(IsDPMInstalled) # IsDPMInstalled function from Functions.ps1
#	{		
#		$DPMVersion = DPMVersion ($Script:DPMFolderDir) 
#		if(($DPMVersion -eq 3) -or ($DPMVersion -eq 4))  # DPM 2010 and DPM 2012
#		{
#			return $true
#		}
#		else
#		{
#			"The current DPM version is " + $DPMVersion + " - rule does not apply." | WriteTo-StdOut 
#		}
#	}
#	return $false
#}

####################################################################################
# Check to be sure the DPM 2010 Agent or 2012 Agent installed on the server
####################################################################################
Function CheckTheAvailableDPMRAVersion
{
	if(IsDPMInstalled)
	{
		$DPMRAVersion = DPMRAVersion ($Script:DPMFolderDir)
		if(($DPMRAVersion -eq 3) -or ($DPMRAVersion -eq 4))  # DPM 2010 agent and DPM 2012 agent
		{
			return $true
		}
		else
		{
			"The current DPM agent version is " + $DPMRAVersion + " - rule does not apply." | WriteTo-StdOut 
		}
	}
	return $false
}

####################################################################################
# Add the TraceLogLevel property to the DPM registory key and restart the dpm related services
####################################################################################
Function AddTheTraceLogLevelRegistryKeyAndRestartServices
{
	if(Test-Path $Script:DPMRegisoryKeyPath)
	{
		$TraceLogLevel = (Get-ItemProperty $Script:DPMRegisoryKeyPath).TraceLogLevel
		if($TraceLogLevel -eq $null)
		{
			New-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel" -Value 0x43e -PropertyType "DWord" 
			"Add the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel on " + $ComputerName | WriteTo-StdOut
		}
		else
		{
			Set-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel" -Value 0x43e
			"Set the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel value to 0x43e on " + $ComputerName | WriteTo-StdOut
		}
	}

	"Restart the DPM, DPM Access Manager and DPMRA services on " + $ComputerName | WriteTo-StdOut
	if(IsDPMServer)
	{
		Restart-Service "DPM"
		Restart-Service "DPM AccessManager Service"
	}
	else
	{
		"DPM, DPM Access Manager services is not available on " + $ComputerName | WriteTo-StdOut
	}
	Restart-Service "DPMRA"
}

####################################################################################
# Remove the TraceLogLevel property from the DPM registory key and restart the dpm related services
####################################################################################
Function RemoveTheTraceLogLevelRegistryKeyAndRestartServices
{
	if(Test-Path $Script:DPMRegisoryKeyPath)
	{
		$TraceLogLevel = (Get-ItemProperty $Script:DPMRegisoryKeyPath).TraceLogLevel
		if($TraceLogLevel -ne $null)
		{
			Remove-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel"
			"Removed the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel on " + $ComputerName | WriteTo-StdOut
		}
	}

	"Restart the DPM, DPM Access Manager and DPMRA services on " + $ComputerName | WriteTo-StdOut
	if(IsDPMServer)
	{
		Restart-Service "DPM"
		Restart-Service "DPM AccessManager Service"
	}
	else
	{
		"DPM, DPM Access Manager services is not available on " + $ComputerName | WriteTo-StdOut
	}
	Restart-Service "DPMRA"
}

####################################################################################
# Record the load dpm console and enumerate the protect server time
####################################################################################
Function RecordScriptRunningTime($StartTime)
{
	$CompletionTime = [DateTime]::Now
	[void][System.Reflection.Assembly]::LoadWithPartialName('System.Core')
	$TimeZone = [System.TimeZoneInfo]::Local | Select-Object -ExpandProperty Id

	$InformationCollected = new-object PSObject
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Time Zone" -Value $TimeZone
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Start Time" -Value $StartTime
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Completion Time" -Value $CompletionTime
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Runing Total Seconds" -Value ([timespan]($CompletionTime - $StartTime)).TotalSeconds
	$InformationCollected | ConvertTo-Xml2 | update-diagreport -id "EnumerateServerTimeFor$ComputerName" -name ($ComputerName + " - Execution time information")	
}

####################################################################################
# For Remote server side verbose logging Phase 1 and 2, will create the txt file.
####################################################################################
Function RemoteServerSideVerboseLoggingPhase($Phase)
{
	"Start verbose logging Phase: " + $Phase + " on remote server: " + $ComputerName | WriteTo-StdOut
	$File = "VerbosePhase" + $Phase + ".txt"
	"For verbose logging Phase" + $Phase | Out-File $File -Encoding "utf8"
	$timeout = 15*60
	do
	{
		$VerbosePhaseFileExist = $true
		if(Test-Path (Join-Path $Pwd.Path $File))
		{
			Start-Sleep -Seconds 3
			$timeout = $timeout - 3

			if($timeout -le 0) # time out occurred, and log the information.
			{
				"[Error] A timeout has occurred. The verbose logging phase ("+ $Phase +") file: " + $File + " is still exist on the " + $ComputerName +", this phase will ended." | WriteTo-StdOut
			}
		}
		else
		{
			$VerbosePhaseFileExist = $false
		}
	} while ($VerbosePhaseFileExist -and ($timeout -gt 0))

	"End verbose logging Phase: " + $Phase + " on remote server: " + $ComputerName | WriteTo-StdOut
}

####################################################################################
# For Local server side verbose logging Phase 1 and 2, will delete the txt file.
####################################################################################
Function LocalServerSideVerboseLoggingPhase($ProtectedServerList, $Phase)
{
	"Start verbose logging Phase: " + $Phase + " on Local Server: " + $ComputerName | WriteTo-StdOut
	$FileName = "VerbosePhase" + $Phase + ".txt"
	$DiagnosticsFolderName = [System.IO.Path]::GetFileName($PWD.Path)
	$FoundPhaseFileMachineList = @("$ComputerName")
	$timeout = 15*60
	$timeoutOccurred = $false
	do 
	{
		$VerbosePhaseFileFound = $true	# assume all machine found the VerbosePhase.txt file
		foreach($machine in $ProtectedServerList)
		{			
			if(-not($FoundPhaseFileMachineList -Contains $machine))
			{
				trap [Exception] 
				{
					$ErrorStd = "[LocalServerSideVerboseLoggingPhase] The following error ocurred when checking if the VerbosePhasePhase"+$Phase+".txt file exists" 
					WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText $ErrorStd
					$error.Clear()
					continue
				}

				$Status = (($ScriptStrings.ID_DPM_Activity_VerboseLogs_Syncronizingexecution_Status) -Replace("%machine%", $machine) -Replace("%Phase%",$Phase))
				Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $Status

				$FileFullPath = Join-Path -Path "\\$machine\admin$\temp\diagnostics\$DiagnosticsFolderName" -ChildPath $FileName
				"Checking for " + $FileFullPath + " (Phase " + $Phase + " ) on Server: " + $machine | WriteTo-StdOut

				if (-not(Test-Path $FileFullPath)) #Check all machines, once found a machine didnot have the file, always set the flag to false.
				{
					$VerbosePhaseFileFound = $false  
					if($timeoutOccurred  -eq $true) #if time out occurred, add the unable communicate machine to list string.
					{
						$UnableCommunicateMachinesString += " " + $machine + ","
					}
				}
				else # if machine has the file, add the machine to list, and next time will not check this machine.
				{
					$FoundPhaseFileMachineList += $machine 
				}
			}
		}
			
		if(($timeoutOccurred -eq $true) -and ($UnableCommunicateMachinesString -ne $null)) #if time out occurred, log the unable communicate machines.
		{
			"[Error] A timeout has occurred. Unable to communicate to the following machine(s):[" + $UnableCommunicateMachinesString + "]" | WriteTo-StdOut
		}	
				
		if($VerbosePhaseFileFound -eq $false)
		{
			Start-Sleep -Seconds 3
			$timeout = $timeout - 3

			if(($timeout -le 0) -and ($timeoutOccurred -eq $false)) #if time out occurred, add 3 seconds to $timeout, make sure loop one more time to log the unable communicated machines. 
			{
				$timeoutOccurred = $true
				$timeout = $timeout + 3
			}
		}
	} while (($VerbosePhaseFileFound -eq $false) -and ($timeout -gt 0))

	if($Phase -eq 2)
	{
		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on Local Server: " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		#-# Get-DiagInput -Id ID_WaitingForReproduceIssue
		Press_s_key
	}

	foreach($machine in $ProtectedServerList)
	{
		if($machine -ne $ComputerName)
		{
			"Remove "+$FileName+" on server: " + $machine | WriteTo-StdOut
			Remove-Item (Join-Path -Path "\\$machine\admin$\temp\diagnostics\$DiagnosticsFolderName" -ChildPath $FileName)
		}
	}

	"End verbose logging Phase: " + $Phase + " on Local Server: " + $ComputerName | WriteTo-StdOut
}

####################################################################################
# Main Logic for collect the VerboseTracing Data
####################################################################################

Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $ScriptStrings.ID_DPM_Activity_VerboseLogs_Status

"here" | out-file C:\temp\function.txt -append

if(CheckTheAvailableDPMRAVersion)
{
	$RuningEnv = Get-TSRemote
	"TS Remote Level: " + $RuningEnv + " on " + $ComputerName | WriteTo-StdOut
	if($RuningEnv -eq 1) #Under TS_Remote environment, but running on the local machine
	{
		$SelectedMachinesPath = Join-Path $Pwd.Path "SelectedMachines.txt"
		if(Test-Path $SelectedMachinesPath)
		{
			$AllProtectedMachines = Get-Content $SelectedMachinesPath

			LocalServerSideVerboseLoggingPhase -ProtectedServerList $AllProtectedMachines -Phase 1

			LocalServerSideVerboseLoggingPhase -ProtectedServerList $AllProtectedMachines -Phase 2
		}
		else
		{
			"Did not found the SelectedMachines.txt" | WriteTo-StdOut
		}

	}
	elseif($RuningEnv -eq 2) #Under TS_Remote environment and running on a remote machine
	{
		RemoteServerSideVerboseLoggingPhase -Phase 1

		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		RemoteServerSideVerboseLoggingPhase -Phase 2
	}
	else  #No TS_Remote environment, local machine runing only.
	{
		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		#_# Get-DiagInput -Id ID_WaitingForReproduceIssue
		Press_s_key
	}
	
	Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $ScriptStrings.ID_DPM_VerboseLogging_Desc

	"Collect the files from " + $Script:DPMFolderDir + "\Temp on " + $ComputerName | WriteTo-StdOut
	$OutputBase= "$ComputerName" + "_DPM_Verbose_Logs"
	CompressCollectFiles -filesToCollect (Join-Path $DPMFolderDir "Temp\*.*") -fileDescription "DPM Verbose Tracing file" -sectionDescription "Verbose Logging Information" -DestinationFileName ($OutputBase + ".zip") -renameoutput $false

	"Removed the sub-key TraceLogLevel on " + $ComputerName | WriteTo-StdOut
	RemoveTheTraceLogLevelRegistryKeyAndRestartServices

	RecordScriptRunningTime -StartTime $StartTime
}
else
{
	"This is not a DPM server or a protect server" | WriteTo-StdOut
}
