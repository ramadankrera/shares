#************************************************
# DC_Setup_AppCompat.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional AppCompat information.
# Called from: TS_AutoAddCommands_Setup.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $ScriptVariable.ID_CTSAddonsDescription

$sectionDescription = "Additional Components"

# detect OS version
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function isOSVersionAffected
{
	if ([int]$bn -gt [int](9600))
	{
		return $true
	}
	else
	{
		return $false
	}
}

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


<#----------Copy Components Registry hive -- done in DC_ServicingLogs.ps1
# $ComponentsHivOutputFileName = Join-Path $pwd.path ($ComputerName + "_reg_Components.HIV")
# copy $ENV:windir\system32\config\components $ComponentsHivOutputFileName /y
$sectionDescription = "Additional Components Registry hive"
$OutputFile = $ComputerName + "_reg_Components.HIV"
$ComponentsHiv = "$ENV:windir\system32\config\components"
if (test-path $ComponentsHiv)
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Copy $ComponentsHiv"
	Copy-Item -Path $ComponentsHiv -Destination $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Components Registry hive file" -SectionDescription $sectionDescription
}
else
{
  "$ComponentsHiv Does not exist" | WriteTo-StdOut
}
#>

#--- Section for things that need to be started early, will check at end of this script if Process has terminated
if (isOSVersionAffected)
{ #write-host -fore cyan "BN=$bn isOSVersionAffected2=True "
	
	$sectionDescription = "Additional Components DXdiag"
	$dxdiagOutputFileName = Join-Path $pwd.path ($ComputerName + "_dxdiag.txt")
	$CommandToRun = "dxdiag /t $dxdiagoutputFileName"
	RunCMD -commandToRun $CommandToRun -collectFiles $true
	#dxdiag takes some number of seconds to write output after completion. -- will check at end 
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "...running: dxdiag /t "
	#$dxdiagID = (Get-Process dxdiag).id
<#	$i = 0
	$maxWasitSec=40
	while (-not (Test-Path $dxdiagOutputFileName))
	{
		$i++
		if ($i -ge $maxWasitSec)
		{
			"[error]:  waited for $maxWasitSec seconds for dxdiag output, giving up." | WriteTo-StdOut
			break
		}
		Start-Sleep 1
	}

	collectfiles -filesToCollect $dxdiagOutputFileName -fileDescription "dxdiag output" -sectionDescription "Additional Components DXdiag"
		#>
}

#--- Section for App Compat Info  Only run if flag set
Write-Host "$(Get-Date -UFormat "%R:%S") : Compress App Compat AppPatch Log files"
	#		Command: All logs in %windir%\AppPatch*\CompatAdmin.log
	$sectiondescription = "Compress AppPatch files"
	$logFilePath = (join-path $env:SystemRoot "AppPatch\CompatAdmin.log")
	if (test-path $logFilePath)
		{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectiondescription
			CompressCollectFiles -filesToCollect $logFilePath -Recursive -fileDescription "App Compat Log Files" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_logs.zip" -RenameOutput $true
		}
	else
		{
		  "$logFilePath Does not exist" | WriteTo-StdOut
		}
	$sectiondescription = "Compress AppPatch64 files"
	$logFilePath = (join-path $env:SystemRoot "AppPatch64\CompatAdmin.log")
	if (test-path $logFilePath)
		{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectiondescription
			CompressCollectFiles -filesToCollect $logFilePath -Recursive -fileDescription "App Compat 64 Log Files" -sectionDescription $sectiondescription -DestinationFileName "AppCompat64_logs.zip" -RenameOutput $true
		}
	else
		{
		  "$logFilePath Does not exist" | WriteTo-StdOut
		}

#----------Event Logs
Write-Host "$(Get-Date -UFormat "%R:%S") : App Compat EventLogs"
	$sectiondescription = "Get EventLog files"
	#		Command: All App Compat EventLogs in %windir%\System32\Winevt\Logs
	#		OutputFileName: AppCompat_*_EventLogs.zip
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*compatibility*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription compatibility*.evtx"
		CompressCollectFiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*compatibility*.evtx") -Recursive -fileDescription "Get Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_compatibility_EventLogs.zip" -RenameOutput $true
	}
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*inventory*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription *inventory*.evtx"
		CompressCollectFiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*inventory*.evtx") -Recursive -fileDescription "Get Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_inventory_EventLogs.zip" -RenameOutput $true
	}
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*program-telemetry*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription *program-telemetry*.evtx"
		CompressCollectFiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*program-telemetry*.evtx") -Recursive -fileDescription "Get Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_program-telemetry_EventLogs.zip" -RenameOutput $true
	}

#----------Dir Outputs
Write-Host "$(Get-Date -UFormat "%R:%S") : Directory outputs"
	$sectionDescription = "Dir C:\Program Files\"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_AppCompat_Dir_ProgramFiles.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	# RunPS "get-Childitem $ENV:Programfiles -recurse -Exclude *Defender*,*ScriptStore*,*CSC*,*RtBackup* -ErrorAction SilentlyContinue"
	$CommandToExecute = 'dir /a /s "C:\Program Files\" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "App Compat: Dir C:\Program Files\ output" -sectionDescription $sectionDescription
	
	$sectionDescription = "Dir C:\Program Files (x86)\"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_AppCompat_Dir_ProgramFilesx86.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "C:\Program Files (x86)" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "App Compat: Dir C:\Program Files (x86)\ output" -sectionDescription $sectionDescription

#----------Registry
Write-Host "$(Get-Date -UFormat "%R:%S") : Registry outputs, will take minutes..."

		$AppCompatFlagsKeyHKLM = 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags'
		$OutputFile= $ComputerName + "_AppCompatFlags_Reg_HKLM.txt"
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get AppCompatFlags_Reg_HKLM file"
		RegQuery -RegistryKeys $AppCompatFlagsKeyHKLM -OutputFile $OutputFile -fileDescription "AppCompatFlags HKLM Reg key" -Recursive $true

		$AppCompatFlagsKeyHKCU = 'HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags'
		$OutputFile= $ComputerName + "_AppCompatFlags_Reg_HKCU.txt"
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get AppCompatFlags_Reg_HKCU file"
		RegQuery -RegistryKeys $AppCompatFlagsKeyHKCU -OutputFile $OutputFile -fileDescription "AppCompatFlags HKCU Reg key" -Recursive $true

		$InstallerKey = 'HKLM\Software\Microsoft\Windows\CurrentVersion\Installer'
		$OutputFile= $ComputerName + "_AppCompat_Reg_WindowsInstaller.txt"
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get Reg_WindowsInstaller file"
		RegQuery -RegistryKeys $Installerkey -OutputFile $OutputFile -fileDescription "Installer Reg key" -Recursive $true

<#		$HKCUsoftwareKey = 'HKCU\Software'
		$OutputFile= $ComputerName + "_reg_HKCU_CurrentUser-Software.txt"
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get HKCU\Software TXT file"
		RegQuery -RegistryKeys $HKCUsoftwareKey -OutputFile $OutputFile -fileDescription "Reg_CurrentUser-Software Hive TXT file" -Recursive $true
		
		$HKLMsoftwareKey = 'HKLM\Software'
		$OutputFile= $ComputerName + "_reg_HKLM_LocalMachine-Software.txt"
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get HKLM\Software TXT file"
		RegQuery -RegistryKeys $HKLMsoftwareKey -OutputFile $OutputFile -fileDescription "Reg_LocalMachine-Software Hive TXT file" -Recursive $true
#>
		# much faster to collect .HIV instead of RegQuery / REG EXPORT
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get Reg Software-User.HIV"
		$OutputFile= $MachineName + "__reg_HKCU-Software-User.HIV"
		RegSave -RegistryKey "HKCU\Software" -OutputFile $OutputFile -fileDescription "HKCU-Software-User Hive"

		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get Reg Software.HIV"
		$OutputFile= $MachineName + "__reg_HKLM-Software.HIV"
		RegSave -RegistryKey "HKLM\Software" -OutputFile $OutputFile -fileDescription "HKLM-Software Hive"

#----------End section
Write-Host "$(Get-Date -UFormat "%R:%S") : App Compat end section"
# Waiting until Process DXdiag completes
	if (Get-Process -Name DXdiag -EA SilentlyContinue) {
		Write-Host "$(Get-Date -UFormat "%R:%S") ...waiting max 40 seconds on DXdiag $dxdiagID to complete"
		#Wait-Process -Id $dxdiagID -Timeout 40 -EA SilentlyContinue
		Wait-Process -Name DXdiag -Timeout 40 -EA SilentlyContinue
		collectfiles -filesToCollect $dxdiagOutputFileName -fileDescription "dxdiag output" -sectionDescription "Additional Components DXdiag"
	}

