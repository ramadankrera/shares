﻿#************************************************
#  DC_CBengine.sp1
#  Author:        Wilson Souza
#  Date Created:  03/09/2016
#  Date Modified: 08/29/2016
#  Description:   This script collects MAB related logs
#************************************************

Import-LocalizedData -BindingVariable LocalsCollectDPMLogs -FileName DC_CBEngine -UICulture en-us

#Azure Installation
$WindowsAzureBackup = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Setup").InstallPath
$DPMInstall         = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\db').sqlserver
$OutputBase         = "Result\" + $ComputerName + "_CBENGINE_online_job_history_.txt" 
$date = (get-date).AddDays(-15)

#Loading Azure PowerShell Module
& ($WindowsAzureBackup+'bin\WABModuleInitScript.ps1')

if ($WindowsAzureBackup)
{
	#MABs online job
	if ($WindowsAzureBackup -and !$DPMInstall)
	{

		$count=0
		while ($count -ne 10)
		{
			$Jobhistorylist = Get-OBJob 100000000 | ? { $_.JobStatus.StartTime -gt $date}
			if (!$Jobhistorylist) { Sleep 2; $count++} else { break }
		}

		$Jobhistorylist = $Jobhistorylist + (Get-OBJob)

		''                                                                                                                                                                                                                                             | Out-File $OutputBase
		'JobType      Start (UTC Time)         End (UTC Time)           State                  Data Transfer (MB)   Name                                   JobId                                  DetailedErrorCode   ErrorCode    ErrorParameterInfo' | Out-File $OutputBase -Append -Width 500
		'----------   ----------------------   ----------------------   --------------------   ------------------   ------------------------------------   ------------------------------------   -----------------   ----------   ------------------' | Out-File $OutputBase -Append -Width 500
 
		foreach ($jobhistory in $Jobhistorylist)
		{

		    $jobTYpe     = $Jobhistory.jobtype
			$jobstate    = @($jobhistory.jobstatus.datasourcestatus.jobstate)
			$JobStartTm  = $jobhistory.JobStatus.StartTime
			$JobEndTm    = $jobhistory.JobStatus.endTime
		    $JobFiles    = $jobhistory.JobStatus.DatasourceStatus.fileprogress.total
			$jobTransfer = @($jobhistory.JobStatus.DatasourceStatus.byteprogress.progress)
		    $JobName     = @($jobhistory.JobStatus.DatasourceStatus.datasource.DataSourceName)
			$JobDEC      = $jobhistory.JobStatus.ErrorInfo.DetailedErrorCode
			$JobErr      = $jobhistory.JobStatus.errorinfo.ErrorCode
			$JobErrParm  = $jobhistory.JobStatus.errorinfo.ErrorParamList.name + ' ' + $jobhistory.JobStatus.errorinfo.ErrorParamList.value
			$JobID       = $jobhistory.JobId

		    if ($jobhistory.JobStatus.DatasourceStatus -eq $null)
			{
				if ($jobhistory.jobstatus.jobstate -eq 'Abort') { $Jobstatus = 'Failed' } else { $Jobstatus = $Jobstate[$count]}
				('{0,-10}   {1,-22}   {2,-22}   {3,-20}   {4,18:N2}   {5,-36}   {6}   {7,17:X}   {8,10}   {9} ' -f $jobtype, $JobStartTm, $JobEndTm, $Jobstatus , "---", "---", $JobID, $JobDEC, $JobErr, $JobErrParm ) | Out-File $OutputBase -Append -Width 500
		    }
		    else
			{
    			$count = 0
		        while ($count -ne $jobstate.count)
			    {
				    if ($Jobstate[$count] -eq 'Abort') { $Jobstatus = 'Failed' } else { $Jobstatus = $Jobstate[$count]}
					if ($jobTransfer[$count] -ne 0) { $JobTransferMB = $jobTransfer[$count]/1024/1024 } else {  $JobTransferMB = 0 } 
    			    ('{0,-10}   {1,-22}   {2,-22}   {3,-20}   {4,18:N2}   {5,-36}   {6}   {7,17:X}   {8,10}   {9}   ' -f $jobtype, $JobStartTm, $JobEndTm, $Jobstatus, $JobTransferMB, $JobName[$count], $JobID, $JobDEC, $JobErr, $JobErrParm ) | Out-File $OutputBase -Append -Width 500
			    	$count++
		        }
			}
		}
	}

	#DPM online job
	If ($WindowsAzureBackup -and $DPMInstall)
	{
		$count=0
		while ($count -ne 10)
		{
			$Jobhistorylist  = @(Get-DPMJob (&hostname) -type CloudBackup -From (get-date).AddDays(-15) | Sort-Object starttime)
			if (!$Jobhistorylist) { Sleep 2; $count++} else { break }
		}

		''                                                                                                                                                                                                                                                     | Out-File $OutputBase -Append -Width 500
		'JobType       Start (UTC Time)         End (UTC Time)           State       Data Transfer (MB)   Production Server                      Name                                   DPM/CBENGINE TaskID                    DetailedErrorCode   ErrorCode'  | Out-File $OutputBase -Append -Width 500
		'-----------   ----------------------   ----------------------   ---------   ------------------   ------------------------------------   ------------------------------------   ------------------------------------   -----------------   ----------' | Out-File $OutputBase -Append -Width 500
		foreach ($jobhistory in $Jobhistorylist)
		{
			$jobTYpe     = $Jobhistory.jobtype
			$jobstatus   = $jobhistory.status
		    $JobStartTm  = $jobhistory.StartTime
			$JobEndTm    = $jobhistory.endTime
			$JobFiles    = $jobhistory.JobStatus.DatasourceStatus.fileprogress.total
			$jobTransfer = $jobhistory.DataSize
			$JobName     = $jobhistory.DataSources
			$JobServer   = $jobhistory.Tasks.ProductionServerName
			[xml]$Error  = $Jobhistory.tasks.errorinfoxml
			$JobDEC      = $error.ErrorInfo.DetailedCode
			[int]$JobErr = $error.ErrorInfo.ErrorCode
			#$JobErrParm  = $jobhistory.JobStatus.errorinfo.ErrorParamList.name + ' ' + $jobhistory.JobStatus.errorinfo.ErrorParamList.value
			$JobID       = $jobhistory.Tasks.taskid.Guid
			if ($jobTransfer -ne 0) { $JobTransferMB = $jobTransfer/1024/1024 } else {  $JobTransferMB = 0 } 
		    ('{0,-11}   {1,-22}   {2,-22}   {3,-9}   {4,18:N2}   {5,-36}   {6,-36}   {7}   {8,17:x}   {9,10:x}' -f $jobtype, $JobStartTm, $JobEndTm, $Jobstatus, $JobTransferMB, $JobServer, $JobName, $JobID, $JobDEC, $JobErr) | Out-File $OutputBase -Append -Width 500
		}
	}


    # Collect CBENGINE logs
	$CBEngineLogFolder = Join-Path $WindowsAzureBackup "Temp\"
	$OutputBase = $ComputerName + "_CBENGINE" 
	CompressCollectFilesForTimePeriod -filesToCollect ($CBEngineLogFolder + "\*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -NumberOfDays 7	

   	$CBEngineConfigFolder = Join-Path $WindowsAzureBackup "Bin\"
    $OutputBase = "$ComputerName$Prefix" + "_cbengine.exe.config"
   	copy ($CBEngineConfigFolder + 'cbengine.exe.config') $OutputBase | out-null
    CollectFiles -filesToCollect $OutputBase -fileDescription "cbengine.exe.config"  -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION 
				
   	$CBEngineConfigFolder = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Config").ScratchLocation
    $OutputBase = "$ComputerName$Prefix" + "_CBSettings.xml"
   	Format-XML ([xml](get-content ($CBEngineConfigFolder + '\CBSettings.xml'))) -indent 4 | out-file $OutputBase | out-null
    CollectFiles -filesToCollect $OutputBase -fileDescription "CBSettings.xml"  -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION 

    $CBEngineConfigFolder = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Config").ScratchLocation
   	dir $CBEngineConfigFolder -recurse | Out-File ("Result\" + $computername + "_CBENGINE_Scratch_Folder.txt")

   	"Microsoft Azure Recovery Services Agent Version.: " + (dir ($WindowsAzureBackup  + 'bin\cbengine.exe')).VersionInfo.FileVersion            | Out-File ("Result\" + $computername + "_CBENGINE_AgentInfo.txt") 
    "Microsoft Azure MachineID.......................: " + (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Config').MachineId  | Out-File ("Result\" + $computername + "_CBENGINE_AgentInfo.txt") -Append -Width 500
   	"Microsoft Azure ResourceID......................: " + (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Config').ResourceId | Out-File ("Result\" + $computername + "_CBENGINE_AgentInfo.txt") -Append -Width 500
    "Microsoft Azure DisableThreadTimeout value......: " + $threadtimeout                                                                       | Out-File ("Result\" + $computername + "_CBENGINE_AgentInfo.txt") -Append -Width 500


	if($debug -eq $true){[void]$shell.popup("Run DC_DPMEventLogs.ps1")}

    # CBENGINE Event Logs

    if (IsDPMInstalled)
    {
	    copy-item $Env:systemroot\System32\winevt\Logs\CloudBackup.evtx ("Result\" + $computername + "_evt_CloudBackup.evtx")
	    Get-WinEvent -path "$Env:systemroot\System32\winevt\Logs\CloudBackup.evtx" > ("Result\" + $computername + "_evt_CloudBackup.txt")
    }
    else
    {
       if ($OSVersion.major -gt 4)
       {
	       $EventLogList = gci HKLM:\System\CurrentControlSet\Services\Eventlog | split-path -leaf | ? { $_ -ne 'Application' -and $_ -ne 'DPM Alerts'-and $_ -ne 'System'}
   	       Foreach ($List in $EventLogList)
	       {
		       $EventLog += '-s "' + $List + '" '
           }	
 	       $command = ".\dumpevt.exe Result\" + $computername + "_evt_ " + $eventlog	
	       invoke-expression -command $command
	       copy-item $Env:systemroot\System32\winevt\Logs\CloudBackup.evtx ("Result\" + $computername + "_evt_CloudBackup.evtx")
	       Get-WinEvent -path "$Env:systemroot\System32\winevt\Logs\CloudBackup.evtx" > ("Result\" + $computername + "_evt_CloudBackup.txt")
       }
       else
       {
    	   $EventLogNames = @(gci HKLM:\System\CurrentControlSet\Services\Eventlog | split-path -leaf | ? { $_ -eq 'Application' -or $_ -eq 'DPM Alerts'-or $_ -eq 'System' })	
       }
    }

    .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -Days 10 -OutputFormats ("CSV","evtx","txt")
}

# SIG # Begin signature block
# MIIa4QYJKoZIhvcNAQcCoIIa0jCCGs4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUiLwJgOjLtrptEC2H418Z5tFr
# ngSgghWDMIIEwzCCA6ugAwIBAgITMwAAAKxjFufjRlWzHAAAAAAArDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwNTAzMTcxMzIz
# WhcNMTcwODAzMTcxMzIzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnyHdhNxySctX
# +G+LSGICEA1/VhPVm19x14FGBQCUqQ1ATOa8zP1ZGmU6JOUj8QLHm4SAwlKvosGL
# 8o03VcpCNsN+015jMXbhhP7wMTZpADTl5Ew876dSqgKRxEtuaHj4sJu3W1fhJ9Yq
# mwep+Vz5+jcUQV2IZLBw41mmWMaGLahpaLbul+XOZ7wi2+qfTrPVYpB3vhVMwapL
# EkM32hsOUfl+oZvuAfRwPBFxY/Gm0nZcTbB12jSr8QrBF7yf1e/3KSiqleci3GbS
# ZT896LOcr7bfm5nNX8fEWow6WZWBrI6LKPx9t3cey4tz0pAddX2N6LASt3Q0Hg7N
# /zsgOYvrlwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFCFXLAHtg1Boad3BTWmrjatP
# lDdiMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAEY2iloCmeBNdm4IPV1pQi7f4EsNmotUMen5D8Dg4rOLE9Jk
# d0lNOL5chmWK+d9BLG5SqsP0R/gqph4hHFZM4LVHUrSxQcQLWBEifrM2BeN0G6Yp
# RiGB7nnQqq86+NwX91pLhJ5LBzJo+EucWFKFmEBXLMBL85fyCusCk0RowdHpqh5s
# 3zhkMgjFX+cXWzJXULfGfEPvCXDKIgxsc5kUalYie/mkCKbpWXEW6gN+FNPKTbvj
# HcCxtcf9mVeqlA5joTFe+JbMygtOTeX0Mlf4rTvCrf3kA0zsRJL/y5JdihdxSP8n
# KX5H0Q2CWmDDY+xvbx9tLeqs/bETpaMz7K//Af4wggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTIMIIE
# xAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHhMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRe
# IZcO9StL0mBQBKGi0oSqkgI44DCBgAYKKwYBBAGCNwIBDDFyMHCgVoBUAFMAeQBz
# AHQAZQBtAEMAZQBuAHQAZQByAEQAUABNAF8ATQBBAEIAXwBnAGwAbwBiAGEAbABf
# AEQAQwBfAEMAQgBFAG4AZwBpAG4AZQAuAHAAcwAxoRaAFGh0dHA6Ly9taWNyb3Nv
# ZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBANoEcC97c1V/gl5YLI7DTP77AgRgJf7e
# TxO+a18ym3M2y3xxT3M9OzpWMuogmGyydIkfgA0a6AppDA668PLpcAMkCS1sVW01
# j15xqzjqbWkxpB75C5+h15+whMdhsv8rwRJwcHA6OJH7cg6wyDW7abi4B2Z8gSG5
# W576loHlRPKT/ulmDb9PK3kgChZ7rWDFcex1m+mZLWsZ207Ni/ggXuoaSzY1Clrg
# EpZ/Q14EHh2jVufPZqsRdfAihsmx/BFNn83hk4AOhSPPrUDL/wCmXC8P0vLEYnS3
# Mlt05aNgQnUx8j8+G8AfVLHk52ugdk7LheAsHZD2W6HJHXb5V6hMd7KhggIoMIIC
# JAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBAhMzAAAArGMW5+NGVbMcAAAAAACsMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0B
# CQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNjA4MzAyMTMxNDlaMCMG
# CSqGSIb3DQEJBDEWBBTuv32YH3oJLEC/U9K9INt61mP2/DANBgkqhkiG9w0BAQUF
# AASCAQCAmysQ3uSpkGogvUjNw1R+7FoWY7PlDejID/NeKmGQxlcmIQlqtpNZ4NMB
# exaOgna9NzvtnPbQ+5uGPQcXlCPphwX4Gb2YPUKk517oM2j+8brAgCnhaD6Hav3V
# R13U+u6FjwhVFbO3BDHwWzRtN46RypTBJ5Zd5TrWkV0EMBXjOH01/LZkgVZwD+Zu
# lk74BpWh5tAWQwvS/dEuRWP+A+Dl4PdYZBJO9g1Gewa6yqNM/Z1KaENu8akzix3i
# k99pPz3M/SDoMhkfem2/gdfRnQP7uXdsnNNYO2l37SyX3vls1n/OXvRCjh4a+Bef
# 6Tf3tSm0p/UAPxnN1OeJSNb1gUnI
# SIG # End signature block
